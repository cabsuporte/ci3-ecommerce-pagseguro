-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 15-Mar-2022 às 15:34
-- Versão do servidor: 5.7.28
-- versão do PHP: 7.4.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_ecci_pagseguro_sandbox`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

DROP TABLE IF EXISTS `categorias`;
CREATE TABLE IF NOT EXISTS `categorias` (
  `categoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_nome` varchar(45) NOT NULL,
  `categoria_ativa` tinyint(1) DEFAULT NULL,
  `categoria_meta_link` varchar(100) DEFAULT NULL,
  `categoria_data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `categoria_data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`categoria_id`, `categoria_nome`, `categoria_ativa`, `categoria_meta_link`, `categoria_data_criacao`, `categoria_data_alteracao`) VALUES
(3, 'Informática', 1, 'informatica', '2021-10-20 14:37:20', '2021-10-27 19:22:50'),
(4, 'Roupas', 1, 'roupas', '2021-10-25 02:41:46', '2021-10-27 18:53:51'),
(5, 'Acessórios', 1, 'acessorios', '2021-10-26 15:39:18', '2021-10-26 15:39:18'),
(6, 'Jogos', 1, 'jogos', '2021-10-26 15:39:29', '2021-10-26 15:39:29'),
(7, 'Esportes', 1, 'esportes', '2021-10-26 15:39:43', '2021-10-26 15:39:43');

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE IF NOT EXISTS `clientes` (
  `cliente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cliente_data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `cliente_nome` varchar(45) NOT NULL,
  `cliente_sobrenome` varchar(150) NOT NULL,
  `cliente_data_nascimento` date DEFAULT NULL,
  `cliente_cpf` varchar(20) NOT NULL,
  `cliente_telefone_fixo` varchar(20) DEFAULT NULL,
  `cliente_telefone_movel` varchar(20) NOT NULL,
  `cliente_cep` varchar(10) NOT NULL,
  `cliente_endereco` varchar(155) NOT NULL,
  `cliente_numero_endereco` varchar(20) NOT NULL,
  `cliente_bairro` varchar(45) NOT NULL,
  `cliente_cidade` varchar(105) NOT NULL,
  `cliente_estado` varchar(2) NOT NULL,
  `cliente_complemento` varchar(145) DEFAULT NULL,
  `cliente_data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `config_correios`
--

DROP TABLE IF EXISTS `config_correios`;
CREATE TABLE IF NOT EXISTS `config_correios` (
  `config_id` int(11) NOT NULL,
  `config_cep_origem` varchar(20) NOT NULL,
  `config_codigo_pac` varchar(10) NOT NULL,
  `config_codigo_sedex` varchar(10) NOT NULL,
  `config_somar_frete` decimal(10,2) NOT NULL,
  `config_valor_declarado` decimal(5,2) NOT NULL,
  `config_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `config_correios`
--

INSERT INTO `config_correios` (`config_id`, `config_cep_origem`, `config_codigo_pac`, `config_codigo_sedex`, `config_somar_frete`, `config_valor_declarado`, `config_data_alteracao`) VALUES
(1, '21311-040', '04510', '04014', '3.50', '21.50', '2021-11-11 05:22:16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `config_pagseguro`
--

DROP TABLE IF EXISTS `config_pagseguro`;
CREATE TABLE IF NOT EXISTS `config_pagseguro` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT,
  `config_email` varchar(255) NOT NULL,
  `config_token` varchar(100) NOT NULL,
  `config_ambiente` tinyint(1) NOT NULL COMMENT '0 -> Ambiente real / 1 -> Ambiente sandbox',
  `config_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `config_pagseguro`
--

INSERT INTO `config_pagseguro` (`config_id`, `config_email`, `config_token`, `config_ambiente`, `config_data_alteracao`) VALUES
(1, 'cabtisuporte@gmail.com', '87845A7050F844CBBA1A3C19494C1AF6', 1, '2021-11-11 05:49:42');

-- --------------------------------------------------------

--
-- Estrutura da tabela `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Estrutura da tabela `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `marcas`
--

DROP TABLE IF EXISTS `marcas`;
CREATE TABLE IF NOT EXISTS `marcas` (
  `marca_id` int(11) NOT NULL AUTO_INCREMENT,
  `marca_nome` varchar(45) NOT NULL,
  `marca_meta_link` varchar(255) NOT NULL,
  `marca_ativa` tinyint(1) DEFAULT NULL,
  `marca_data_criacao` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `marca_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`marca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `marcas`
--

INSERT INTO `marcas` (`marca_id`, `marca_nome`, `marca_meta_link`, `marca_ativa`, `marca_data_criacao`, `marca_data_alteracao`) VALUES
(1, 'Asus', 'asus', 1, '2021-09-02 13:51:09', NULL),
(2, 'LG', 'lg', 1, '2021-09-02 13:51:09', '2021-11-22 02:34:54'),
(3, 'Gigabyte', 'gigabyte', 1, '2021-09-27 15:37:35', NULL),
(4, 'Philco', 'philco', 0, '2021-09-27 15:37:47', NULL),
(5, 'Samsung', 'samsung', 1, '2021-10-27 21:16:01', NULL),
(6, 'AOC', 'aoc', 0, '2021-10-27 21:16:15', NULL),
(7, 'HP', 'hp', 1, '2021-10-27 21:17:05', NULL),
(8, 'Dell', 'dell', 1, '2021-10-27 21:17:19', NULL),
(9, 'Acer', 'acer', 1, '2021-11-09 17:10:09', NULL),
(10, 'Nintendo', 'nintendo', 1, '2021-11-22 02:34:30', NULL),
(11, 'Dice', 'dice', 1, '2021-11-22 02:34:44', NULL),
(12, 'Adidas', 'adidas', 1, '2021-11-22 02:35:17', NULL),
(13, 'Nike', 'nike', 1, '2021-11-22 02:35:26', NULL),
(14, 'Menina Ju', 'menina-ju', 1, '2021-11-22 02:35:36', NULL),
(15, 'Ubisoft', 'ubisoft', 1, '2021-11-25 17:51:01', NULL),
(16, 'Origin', 'origin', 1, '2021-11-25 17:51:11', NULL),
(17, 'Steam', 'steam', 0, '2021-11-25 17:51:18', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE IF NOT EXISTS `pedidos` (
  `pedido_id` int(11) NOT NULL AUTO_INCREMENT,
  `pedido_codigo` varchar(8) DEFAULT NULL,
  `pedido_cliente_id` int(11) DEFAULT NULL,
  `pedido_valor_produtos` decimal(15,2) DEFAULT NULL,
  `pedido_valor_frete` decimal(15,2) DEFAULT NULL,
  `pedido_valor_final` decimal(15,2) DEFAULT NULL,
  `pedido_forma_envio` tinyint(1) DEFAULT NULL COMMENT '1 = Correios Sedex---------------------2 - Correios PAC',
  `pedido_data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pedido_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pedido_id`),
  KEY `pedido_cliente_id` (`pedido_cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos_produtos`
--

DROP TABLE IF EXISTS `pedidos_produtos`;
CREATE TABLE IF NOT EXISTS `pedidos_produtos` (
  `pedido_id` int(11) DEFAULT NULL,
  `produto_id` int(11) DEFAULT NULL,
  `produto_nome` varchar(200) NOT NULL,
  `produto_quantidade` int(11) NOT NULL,
  `produto_valor_unitario` decimal(15,2) NOT NULL,
  `produto_valor_total` decimal(15,2) NOT NULL,
  KEY `pedido_id` (`pedido_id`,`produto_id`),
  KEY `produto_id` (`produto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `produto_id` int(11) NOT NULL AUTO_INCREMENT,
  `produto_categoria_id` int(11) DEFAULT NULL,
  `produto_subcategoria_id` int(11) DEFAULT NULL,
  `produto_marca_id` int(11) DEFAULT NULL,
  `produto_codigo` varchar(45) DEFAULT NULL,
  `produto_nome` varchar(255) DEFAULT NULL,
  `produto_meta_link` varchar(255) DEFAULT NULL,
  `produto_download` int(1) DEFAULT NULL,
  `produto_peso` int(11) DEFAULT '0',
  `produto_altura` int(11) DEFAULT '0',
  `produto_largura` int(11) DEFAULT '0',
  `produto_comprimento` int(11) DEFAULT '0',
  `produto_valor` varchar(45) DEFAULT NULL,
  `produto_destaque` tinyint(1) DEFAULT NULL,
  `produto_controlar_estoque` tinyint(1) DEFAULT NULL,
  `produto_quantidade_estoque` int(11) DEFAULT '0',
  `produto_ativo` tinyint(1) DEFAULT NULL,
  `produto_descricao` longtext,
  `produto_data_cadastro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `produto_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`produto_id`),
  KEY `produto_categoria_id` (`produto_subcategoria_id`),
  KEY `produto_marca_id` (`produto_marca_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`produto_id`, `produto_categoria_id`, `produto_subcategoria_id`, `produto_marca_id`, `produto_codigo`, `produto_nome`, `produto_meta_link`, `produto_download`, `produto_peso`, `produto_altura`, `produto_largura`, `produto_comprimento`, `produto_valor`, `produto_destaque`, `produto_controlar_estoque`, `produto_quantidade_estoque`, `produto_ativo`, `produto_descricao`, `produto_data_cadastro`, `produto_data_alteracao`) VALUES
(4, 3, 2, 9, '72196548', 'Aspire 5 53T9', 'aspire-5-53t9', NULL, 2, 15, 15, 15, '2599.99', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-10 05:02:52', '2022-02-21 03:24:53'),
(5, 3, 2, 8, '09728154', 'Dell 6320', 'dell-6320', NULL, 1, 15, 15, 15, '1250.00', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s', '2021-11-17 03:44:53', '2022-02-21 03:24:59'),
(6, 3, 2, 7, '60954378', 'HP 6930p', 'hp-6930p', NULL, 1, 15, 15, 15, '1320.00', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s', '2021-11-17 03:46:02', '2022-02-21 03:25:03'),
(7, 6, 14, 10, '14706389', 'Mario World', 'mario-world', NULL, 1, 1, 1, 1, '250.00', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2021-11-22 02:38:46', '2022-02-21 03:25:09'),
(8, 6, 15, 15, '63419578', 'Ghost Recon Wildlands', 'ghost-recon-wildlands', NULL, 1, 15, 15, 15, '399.00', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:01:11', '2021-12-22 15:55:12'),
(9, 6, 14, 16, '93604751', 'Battlefield War Final', 'battlefield-war-final', NULL, 0, 0, 0, 0, '499.50', 1, 1, 999, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:04:08', '2021-11-25 19:45:47'),
(10, 4, 8, 12, '68937124', 'Short Pequeno', 'short-pequeno', NULL, 1, 1, 1, 1, '59.99', 1, 1, 200, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:06:30', '2021-11-25 19:44:47'),
(11, 4, 8, 12, '89364072', 'Short Médio', 'short-medio', NULL, 2, 3, 4, 5, '79.99', 1, 1, 200, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:07:42', '2021-11-25 19:45:39'),
(12, 4, 19, 14, '38921465', 'Blusa Pequena', 'blusa-pequena', NULL, 4, 5, 6, 7, '69.59', 1, 1, 888, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:09:58', '2021-11-25 19:43:39'),
(13, 4, 19, 14, '29068435', 'Blusa Média', 'blusa-media', NULL, 2, 4, 6, 8, '57.99', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:24:55', '2021-11-25 19:43:31'),
(14, 4, 19, 14, '67482935', 'Blusa Grande', 'blusa-grande', NULL, 1, 2, 4, 5, '79.99', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:26:20', '2021-11-25 19:44:37'),
(15, 4, 9, 12, '98072143', 'Blusa Pequena', 'blusa-pequena', NULL, 1, 2, 1, 1, '49.49', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:28:37', '2021-11-25 19:46:53'),
(16, 4, 9, 12, '97408512', 'Blusa Pequena', 'blusa-pequena', NULL, 1, 2, 2, 1, '49.50', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:29:25', '2021-11-25 19:46:24'),
(17, 4, 9, 12, '96730214', 'Blusa Média', 'blusa-media', NULL, 2, 1, 2, 2, '61.99', 1, 1, 200, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:30:20', '2021-11-25 19:46:04'),
(18, 4, 9, 13, '24619703', 'Blusa Grande', 'blusa-grande', NULL, 1, 15, 15, 15, '76.99', 1, 1, 200, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:31:05', '2021-12-21 15:45:08'),
(19, 4, 9, 13, '42075613', 'Camisa Grande', 'camisa-grande', NULL, 3, 3, 2, 2, '109.99', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:32:50', '2021-11-25 19:43:49'),
(20, 3, 3, 2, '70218436', 'Desktop Core i5', 'desktop-core-i5', NULL, 30, 12, 12, 15, '1799.09', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:34:58', '2021-11-25 19:44:58'),
(21, 3, 3, 9, '20158493', 'Desktop Core i5 Gamer', 'desktop-core-i5-gamer', NULL, 3, 15, 15, 15, '3599.00', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:36:35', '2021-12-23 03:17:13'),
(22, 3, 3, 8, '28634059', 'Desktop Core i9 Gamer', 'desktop-core-i9-gamer', NULL, 28, 10, 13, 11, '4699.90', 1, 1, 200, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:38:16', '2021-11-25 19:43:22'),
(23, 5, 20, 1, '61084375', 'RTX DDR5 8GB 128bits', 'rtx-ddr5-8gb-128bits', NULL, 2, 3, 4, 3, '1499.00', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:42:52', '2021-11-25 19:44:05'),
(24, 5, 21, 1, '65132980', 'TUF GAMING', 'tuf-gaming', NULL, 1, 1, 2, 2, '699.99', 1, 1, 300, 1, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#039;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', '2021-11-25 18:44:28', '2021-11-25 19:44:27');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos_fotos`
--

DROP TABLE IF EXISTS `produtos_fotos`;
CREATE TABLE IF NOT EXISTS `produtos_fotos` (
  `foto_id` int(11) NOT NULL AUTO_INCREMENT,
  `foto_produto_id` int(11) DEFAULT NULL,
  `foto_caminho` varchar(255) NOT NULL,
  PRIMARY KEY (`foto_id`),
  KEY `fk_foto_produto_id` (`foto_produto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos_fotos`
--

INSERT INTO `produtos_fotos` (`foto_id`, `foto_produto_id`, `foto_caminho`) VALUES
(76, 7, '0e20751aa6ba7b99ae09531b297788cf.jpg'),
(82, 22, '72e1ecf0fc45c22e1e2f3fd60fc14b3c.jpg'),
(83, 22, '6a2e7215b3c64e2c95a9ac8f7fcdf31b.jpg'),
(84, 22, '19701423e697e6f21ad303d6d0f4b66f.jpg'),
(85, 22, '2733ea8a13552d9c305c9f6e39542432.jpg'),
(86, 22, 'cc7d431b708c327537c72a5795408fe3.jpg'),
(87, 22, '758b8eb757d3d3be2aa5153e436f888d.jpg'),
(88, 13, '5c884bca3577d107776f31268acf913c.jpg'),
(89, 13, '93d625787da6b501699ce5ea20eabbe5.jpg'),
(90, 12, '944a457613dbce11583f80f2adc43df7.jpg'),
(91, 12, 'c85371886c8ba91cd01252e19cb8f21f.jpeg'),
(92, 19, '0eafc24d8b9483bb3e2bffc18ef30833.jpg'),
(95, 23, '344ba442054a621651a6cd08a0c32c96.jpg'),
(102, 24, '9cce3b6ada7854cd9ab82f73210cfd0b.png'),
(103, 24, '1b06a91cb87b2dc8b61980c3f5ca7bd2.jpg'),
(104, 24, 'e26d5edb22e17d65824b20dd7fa41e0c.png'),
(105, 24, '025812396f7e938dc0bceb1259571c15.jpg'),
(106, 14, 'b4cc3c4bb81e9cc864912c29243715ae.jpg'),
(107, 14, '9c6f361653ac5366f18d1f26fd6b0424.jpg'),
(108, 14, '7410db1ac683d6e3a545300fc29368d4.jpeg'),
(109, 10, '8f6c2dd2e5c49b390b287ab13ed04371.jpg'),
(110, 10, '485e4fbc14c0840053ee2757c23f886c.jpg'),
(111, 10, '2a5436135505c978e3a6eb8a967d0d64.jpg'),
(112, 20, '93ad2bde1e024c15ec0073461e44618e.jpg'),
(113, 20, '1d4bd6cb7d2bcbe537f3ab08f6d23821.jpg'),
(114, 20, '67ef3a18b0046de6351624c5cb21a639.jpg'),
(118, 11, 'b3ec1130cdbca7e5dcb2a075cec897c6.jpg'),
(119, 11, '3aa47b7593d822f32838e64402572f57.jpg'),
(120, 11, 'b0a9c00c2ba5d934a34700c63bffe2fb.jpg'),
(121, 11, 'ee2acc1f8abee59d6d648825c5ac1926.jpg'),
(122, 9, '7736b58fd6880caac2f3f7b69c52b48d.jpg'),
(123, 9, '0cd610587e6e5664f9fb1c70ccdc92ac.jpg'),
(124, 9, 'e253a9621716ec1fdc3443ee8de9ecbd.jpg'),
(125, 9, '04cc52bc966461480531ffd61e19ce1a.jpg'),
(126, 17, '907888f05b671bd4f0d9357a69fbe026.jpg'),
(127, 16, '290f17ae5c361a27b96a3882b208c473.jpg'),
(128, 15, '47e2aab850ad4165ccd47348f6591a63.jpg'),
(149, 18, '5b10a8378f4368b74be66e3a7aad2dd9.jpg'),
(150, 8, '804affcac2350538fd63d7fb34552c23.jpg'),
(151, 8, 'c4f407bfa80a324e3b51eba65bf06bf1.jpg'),
(152, 8, '18d3e2d7c2f9c6b59342af586199198c.jpg'),
(153, 8, 'e883bd02d57c06408b7c45be2ca9a92b.jpg'),
(154, 8, '5b68a6f35b8074cc3b4e6cb443c06ef0.jpg'),
(155, 8, 'e7f71481808d3b123990df76ab239688.jpg'),
(156, 4, '0f312b97243c4f46884515744000a1ce.jpg'),
(157, 4, 'da25b2db9c676cbcf52448012d95c9ee.jpg'),
(158, 4, '5c6e2448ec913d725b0ece723cda25e1.jpg'),
(159, 21, '598ced05259f23e7aa9f3643c3351ad2.jpg'),
(160, 21, '7e23ca6f40c1aba8c3187370f0d41386.jpeg'),
(161, 21, '6951f62a8d09ca50209616843495904d.jpg'),
(162, 21, '1bbbda4f7c6a790c787f35a1f53b1ac3.jpg'),
(163, 5, '83b9d5b4ad6ef297fc0a02ee00890ffe.jpg'),
(164, 5, 'f67de5cd131b14d2b0b2ecfe8430bb91.jpg'),
(165, 5, 'c9e5fb7560bf5f83324fe848e3b75aef.jpg'),
(167, 6, 'b06f4b8e8c0db66f6bc8216e5c843f7d.jpg'),
(168, 6, '47c64c5870c41d908373a4d6de1d9d6f.jpg'),
(169, 6, '189181011901b2917ae292d44e2b2db6.jpg'),
(170, 6, '91b577f0df79f143f21b5b2e7b03adec.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sistema`
--

DROP TABLE IF EXISTS `sistema`;
CREATE TABLE IF NOT EXISTS `sistema` (
  `sistema_id` int(11) NOT NULL,
  `sistema_razao_social` varchar(145) DEFAULT NULL,
  `sistema_nome_fantasia` varchar(145) DEFAULT NULL,
  `sistema_cnpj` varchar(25) DEFAULT NULL,
  `sistema_ie` varchar(25) DEFAULT NULL,
  `sistema_telefone_fixo` varchar(25) DEFAULT NULL,
  `sistema_telefone_movel` varchar(25) NOT NULL,
  `sistema_email` varchar(100) DEFAULT NULL,
  `sistema_site_url` varchar(100) DEFAULT NULL,
  `sistema_cep` varchar(25) DEFAULT NULL,
  `sistema_endereco` varchar(145) DEFAULT NULL,
  `sistema_numero` varchar(25) DEFAULT NULL,
  `sistema_cidade` varchar(45) DEFAULT NULL,
  `sistema_estado` varchar(2) DEFAULT NULL,
  `sistema_produtos_destaques` int(11) DEFAULT NULL,
  `sistema_texto` text,
  `sistema_data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `sistema`
--

INSERT INTO `sistema` (`sistema_id`, `sistema_razao_social`, `sistema_nome_fantasia`, `sistema_cnpj`, `sistema_ie`, `sistema_telefone_fixo`, `sistema_telefone_movel`, `sistema_email`, `sistema_site_url`, `sistema_cep`, `sistema_endereco`, `sistema_numero`, `sistema_cidade`, `sistema_estado`, `sistema_produtos_destaques`, `sistema_texto`, `sistema_data_alteracao`) VALUES
(1, 'Loja virtual Inc', 'Vende tudo!', '80.838.809/0001-26', '683.90228-49', '(21) 2233-4455', '(21) 99988-7766', 'vendetudo@contato.com.br', 'http://vendetudo.com.br', '21311-040', 'Rua Cajru', '430', 'Cascadura', 'RJ', 10, 'Preço e qualidade!', '2021-12-08 02:20:42');

-- --------------------------------------------------------

--
-- Estrutura da tabela `subcategorias`
--

DROP TABLE IF EXISTS `subcategorias`;
CREATE TABLE IF NOT EXISTS `subcategorias` (
  `subcategoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria_id` int(11) DEFAULT NULL,
  `subcategoria_nome` varchar(45) DEFAULT NULL,
  `subcategoria_ativa` tinyint(1) DEFAULT NULL,
  `subcategoria_meta_link` varchar(100) DEFAULT NULL,
  `subcategoria_data_criacao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `subcategoria_data_alteracao` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`subcategoria_id`) USING BTREE,
  KEY `FK_CATEGORIAS_ID` (`categoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `subcategorias`
--

INSERT INTO `subcategorias` (`subcategoria_id`, `categoria_id`, `subcategoria_nome`, `subcategoria_ativa`, `subcategoria_meta_link`, `subcategoria_data_criacao`, `subcategoria_data_alteracao`) VALUES
(1, 3, 'Ultrabook', 1, 'core-i3', '2021-10-25 04:19:43', '2021-10-25 04:19:43'),
(2, 3, 'Notebook', 1, 'core-i5', '2021-10-25 04:19:43', '2021-10-25 04:19:43'),
(3, 3, 'Desktop', 1, 'desktop', '2021-10-26 16:00:36', '2021-10-26 16:00:36'),
(4, 5, 'Mouse', 1, 'mouse', '2021-10-26 16:01:11', '2021-10-26 16:01:11'),
(5, 5, 'Teclado', 1, 'teclado', '2021-10-26 16:01:26', '2021-10-26 16:01:26'),
(7, 7, 'Raquete de pingpong', 1, 'raquete-de-pingpong', '2021-10-26 16:02:01', '2021-10-26 16:02:01'),
(8, 4, 'Short Feminino', 1, 'short-feminino', '2021-11-22 02:29:57', '2021-11-22 02:29:57'),
(9, 4, 'Blusa Masculina', 1, 'blusa-masculina', '2021-11-22 02:31:10', '2021-11-22 02:31:10'),
(10, 5, 'Bijuterias', 1, 'bijuterias', '2021-11-22 02:31:43', '2021-11-22 02:31:43'),
(11, 5, 'Suporte Celular', 1, 'suporte-celular', '2021-11-22 02:32:08', '2021-11-22 02:32:08'),
(12, 7, 'Futebol', 1, 'futebol', '2021-11-22 02:32:26', '2021-11-22 02:32:26'),
(13, 7, 'Lutas', 1, 'lutas', '2021-11-22 02:32:40', '2021-11-22 02:32:40'),
(14, 6, 'PC', 1, 'pc', '2021-11-22 02:33:30', '2021-11-22 02:33:30'),
(15, 6, 'Console', 1, 'console', '2021-11-22 02:33:48', '2021-11-22 02:33:48'),
(18, 6, 'Mobile', 1, 'mobile', '2021-11-25 17:48:32', '2021-11-25 17:48:32'),
(19, 4, 'Blusa Feminina', 1, 'blusa-feminina', '2021-11-25 18:08:38', '2021-11-25 18:08:38'),
(20, 5, 'Placa de vídeo', 1, 'placa-de-video', '2021-11-25 18:40:56', '2021-11-25 18:40:56'),
(21, 5, 'Plava mãe', 1, 'plava-mae', '2021-11-25 18:41:14', '2021-11-25 18:41:14'),
(22, 5, 'Fonte', 1, 'fonte', '2021-11-25 18:41:34', '2021-11-25 18:41:34');

-- --------------------------------------------------------

--
-- Estrutura da tabela `transacoes`
--

DROP TABLE IF EXISTS `transacoes`;
CREATE TABLE IF NOT EXISTS `transacoes` (
  `transacao_id` int(11) NOT NULL AUTO_INCREMENT,
  `transacao_pedido_id` int(11) DEFAULT NULL,
  `transacao_cliente_id` int(11) DEFAULT NULL,
  `transacao_data` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `transacao_codigo_hash` varchar(255) DEFAULT NULL,
  `transacao_tipo_metodo_pagamento` tinyint(1) DEFAULT NULL COMMENT '1 = Cartão | 2 = Boleto | 3 = Transferência',
  `transacao_codigo_metodo_pagamento` varchar(10) DEFAULT NULL,
  `transacao_link_pagamento` varchar(255) DEFAULT NULL,
  `transacao_banco_escolhido` varchar(20) DEFAULT NULL,
  `transacao_valor_bruto` decimal(15,2) DEFAULT NULL,
  `transacao_valor_taxa_pagseguro` decimal(15,2) DEFAULT NULL,
  `transacao_valor_liquido` decimal(15,2) DEFAULT NULL,
  `transacao_numero_parcelas` int(11) DEFAULT NULL,
  `transacao_valor_parcela` decimal(15,2) DEFAULT NULL,
  `transacao_status` tinyint(1) DEFAULT NULL COMMENT 'Verificar documentação',
  `transacao_data_alteracao` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`transacao_id`),
  KEY `transacao_pedido_id` (`transacao_pedido_id`,`transacao_cliente_id`),
  KEY `fk_transacao_cliente_id` (`transacao_cliente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`),
  UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  UNIQUE KEY `uc_remember_selector` (`remember_selector`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$12$brXXOrkj314z5.uHv7fNLuaDOgN23NsoetFCLaG9fHjHg3lCOdrmi', 'admin@admin.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1647367330, 1, 'Admin', 'istrator', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users_groups`
--

DROP TABLE IF EXISTS `users_groups`;
CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `fk_pedido_cliente_id` FOREIGN KEY (`pedido_cliente_id`) REFERENCES `clientes` (`cliente_id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `produtos_fotos`
--
ALTER TABLE `produtos_fotos`
  ADD CONSTRAINT `fk_foto_produto_id` FOREIGN KEY (`foto_produto_id`) REFERENCES `produtos` (`produto_id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `subcategorias`
--
ALTER TABLE `subcategorias`
  ADD CONSTRAINT `FK_CATEGORIAS_ID` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`categoria_id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `transacoes`
--
ALTER TABLE `transacoes`
  ADD CONSTRAINT `fk_transacao_cliente_id` FOREIGN KEY (`transacao_cliente_id`) REFERENCES `clientes` (`cliente_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_transacao_pedido_id` FOREIGN KEY (`transacao_pedido_id`) REFERENCES `pedidos` (`pedido_id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
