var App = function () {
    var calcula_frete = function () {
        $("#btn-calcula-frete").on('click', function () { // Evento se clicar pegar os dados de dois elementos HTML(input e button).
            var produto_id = $(this).attr('data-id'); // Variavel que pega o id do produto através do atributo 'data-id' no botão que submete o formulário.
            var cep = $("#cep").val(); // Variável que pega o valor que é digitado no inout texto do formulário.

            // alert('Produto ID: ' + produto_id + ' - CEP: ' + cep); // Alert criado para teste!

            $.ajax({
                type: 'post', // Metodo de envio do formulário.
                url: BASE_URL + 'ajax/index', // Pagina que irá trabalhar com conjunto a obtenção dos dados.
                dataType: 'json', // Tipo de comunicação para pegar os dados.
                data: {// Seta os dados a serem obtidos.
                    cep: cep,
                    produto_id: produto_id,
                },
                beforeSend: function () {
                    $('#btn-calcula-frete').html('<span class="text-white"><i class="fa fa-cog fa-spin">&nbsp;</i>Calculando</span>');
                }
            }).then(function (response) { // Se der erro, envia mensagem.
                $('#btn-calcula-frete').html('Calcular');
                $('#retorno-frete').html(response.retorno_endereco);

                console.log(response);
            });
        });
    };

    var add_item_cart = function () {
        $('.btn-add-produto').on('click', function () {
            var produto_id = $(this).attr('data-id');
            var produto_quantidade = $('#produto_quantidade_estoque').val();

//            alert(produto_id + ' -- ' + produto_quantidade);

            $.ajax({
                type: 'post', // Metodo de envio do formulário.
                url: BASE_URL + 'carrinho/inserir', // Pagina que irá trabalhar com conjunto a obtenção dos dados.
                dataType: 'json', // Tipo de comunicação para pegar os dados.
                data: {// Seta os dados a serem obtidos da clase Carrinho_compras.
                    produto_id: produto_id,
                    produto_quantidade: produto_quantidade
                },
                beforeSend: function () {
                    $('.btn-add-produto').html('<span class="text-white"><i class="fa fa-cog fa-spin">&nbsp;</i>Adicionando...</span>');
                }
            }).then(function (response) { // Se der erro, envia mensagem.
                $('.btn-add-produto').html('<i class="fa fa-plus-circle"></i> Adicionar');
                console.log(response);
            });
        });
    }

    return{
        init: function () {
            calcula_frete();
            add_item_cart();
        }
    }
}(); // Inicializa ao carregar o script.

jQuery(document).ready(function () {
    $(window).keydown(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });
    App.init();
});