var App = function () {
    var calcula_frete = function () {
        $("#btn-calcula-frete").on('click', function () { // Evento se clicar pegar os dados de dois elementos HTML(input e button).
            var produto_id = $(this).attr('data-id'); // Variavel que pega o id do produto através do atributo 'data-id' no botão que submete o formulário.
            var cep = $("#cep").val(); // Variável que pega o valor que é digitado no inout texto do formulário.

            // alert('Produto ID: ' + produto_id + ' - CEP: ' + cep); // Alert criado para teste!

            $.ajax({
                type: 'post', // Metodo de envio do formulário.
                url: BASE_URL + 'ajax/index', // Pagina que irá trabalhar com conjunto a obtenção dos dados.
                dataType: 'json', // Tipo de comunicação para pegar os dados.
                data: {// Seta os dados a serem obtidos.
                    cep: cep,
                    produto_id: produto_id,
                }
            }).then(function (response) { // Se der erro, envia mensagem.
                $('#retorno-frete').html(response.retorno_endereco);
                
                console.log(response);
            });
        });
    };
    return{
        init: function () {
            calcula_frete();
        }
    }
}(); // Inicializa ao carregar o script.

jQuery(document).ready(function () {
    $(window).keydown(function (event) {
        if (event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });
    App.init();
});