<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Marcas extends CI_Controller {

    public function index($marca_meta_link = NULL) {
        if (!$marca_meta_link || !$marca = $this->Core_model->get_by_id('marcas', array('marca_meta_link' => $marca_meta_link))) {
            redirect('/');
        } else {
            // Se der errado volta para página de formulário com msg de erro.
            $sistema = info_header_footer();

            $data = array(
                'sistema' => info_header_footer(),
                'titulo' => 'Produtos da marca ' . $marca->marca_nome,
                'marca' => $marca->marca_nome,
                'produtos' => $this->Produtos_model->get_all_by(array('marca_meta_link' => $marca_meta_link)),
            );

//            echo '<pre>';
//            print_r($data);
//            exit();

            $this->load->view('site/layout/head', $data);
            $this->load->view('site/layout/_navbar');
            $this->load->view('site/marcas/index');
            $this->load->view('site/layout/footer');
        }
    }

}
