<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index() {
        $sistema = info_header_footer();
        
        $data = array(
            'titulo' => 'Seja bem vindo(a) a loja virtual ' . $sistema->sistema_nome_fantasia,
            'sistema' => info_header_footer(),
            'produtos_destaques' => $this->Loja_model->get_produtos_destaques($sistema->sistema_produtos_destaques),
        );
        
        $this->load->view('site/layout/head', $data);
        $this->load->view('site/layout/_navbar');
        $this->load->view('site/home/index');
        $this->load->view('site/layout/footer');
    }

}
