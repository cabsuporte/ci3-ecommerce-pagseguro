<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Categorias extends CI_Controller {

    public function index($categoria_meta_link = NULL) {
        if (!$categoria_meta_link || !$categoria = $this->Core_model->get_by_id('categorias', array('categoria_meta_link' => $categoria_meta_link))) {
            redirect('/');
        } else {
            // Se der errado volta para página de formulário com msg de erro.
            $sistema = info_header_footer();

            $data = array(
                'sistema' => info_header_footer(),
                'titulo' => 'Produtos da categoria ' . $categoria->categoria_nome,
                'categoria' => $categoria->categoria_nome,
                'produtos' => $this->Produtos_model->get_all_by(array('categoria_meta_link' => $categoria_meta_link)),
            );

//            echo '<pre>';
//            print_r($data);
//            exit();

            $this->load->view('site/layout/head', $data);
            $this->load->view('site/layout/_navbar');
            $this->load->view('site/categorias/index');
            $this->load->view('site/layout/footer');
        }
    }

}
