<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Subcategorias extends CI_Controller {

    public function index($subcategoria_meta_link = NULL) {
        if (!$subcategoria_meta_link || !$subcategoria = $this->Core_model->get_by_id('subcategorias', array('subcategoria_meta_link' => $subcategoria_meta_link))) {
            redirect('/');
        } else {
            // Se der errado volta para página de formulário com msg de erro.
            $sistema = info_header_footer();

            $data = array(
                'sistema' => info_header_footer(),
                'titulo' => 'Produtos da subcategoria ' . $subcategoria->subcategoria_nome,
                'subcategoria' => $subcategoria->subcategoria_nome,
                'produtos' => $this->Produtos_model->get_all_by(array('subcategoria_meta_link' => $subcategoria_meta_link)),
            );

            foreach ($data['produtos']as $produto) {
                $data['categoria_nome'] = $produto->categoria_nome;
                $data['categoria_meta_link'] = $produto->categoria_meta_link;
            }

//            echo '<pre>';
//            print_r($data);
//            exit();

            $this->load->view('site/layout/head', $data);
            $this->load->view('site/layout/_navbar');
            $this->load->view('site/subcategorias/index');
            $this->load->view('site/layout/footer');
        }
    }

}
