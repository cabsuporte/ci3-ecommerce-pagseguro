<?php

defined('BASEPATH')OR exit('Nenhuma ação permitida nesta página');

class Carrinho extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
         $this->load->library('Carrinho_compras');
    }

    public function index() {
        // Nothing
    }

    public function Inserir() {        
        $produto_id = (int) $this->input->post('produto_id'); // Na view HTML o elemento que vai adicionar valor neste input-POST é o atributo DATA-ID de um botão!
        $produto_quantidade = (int) $this->input->post('produto_quantidade_estoque');

        $retorno = array(); // Array de controle de retorno de mensagens para o usuário!

        if (!$produto_id || $produto_quantidade < 1) {
            $retorno['erro'] = 1;
            $retorno['mensagem'] = 'Informe a quantidade maior que Zero';
        } else {
            // Continua o processamento... Verificamos a existencia do produto.
            if (!$produto = $this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))) { // Linha de criação do objeto $produto.
                $retorno['erro'] = 2;
                $retorno['mensagem'] = 'Produto não encontrado!';
            } else {
                // Sucesso... O produto existe... Agora comparamos a quantidade em estoqeu com o que veio via post
                if ($produto_quantidade > $produto->produto_quantidade_estoque) {
                    $retorno['erro'] = 3;
                    $retorno['mensagem'] = 'Infelizmente só temos ' . $produto->produto_quantidade_estoque . ' em estoque!';
                } else {
                    // Sucesso... estoque disponivel
                    $this->Carrinho_compras->INSERIR($produto_id, $produto_quantidade); // Tá dando erro nesta linha, as variaveis estão vazias! 
                    $retorno['erro'] = 4;
                    $retorno['mensagem'] = 'Produto adicionado com sucesso.';
                }
            }
        }
        echo json_encode($retorno);
    }
}
