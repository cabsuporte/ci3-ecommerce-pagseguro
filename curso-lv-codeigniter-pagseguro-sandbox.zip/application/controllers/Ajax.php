<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Ajax extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        $this->form_validation->set_rules('cep', 'CEP do destino', 'trim|required|exact_length[9]');
        $this->form_validation->set_rules('produto_id', 'Produto ID', 'trim|required');

        $retorno = array();

        if ($this->form_validation->run()) { // Sucesso
            $produto_id = (int) $this->input->POST('produto_id');

            if (!$produto = $this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))) { // Se o produto não for encontrado exibe a mensagem de erro.
                $retorno['erro'] = 3;
                $retorno['retorno_endereco'] = '<p class="text-danger">Não encontramos o PRODUTO em nossa base de dados</p>';
                echo json_encode($retorno);
                exit();
            } else {
                // Inicio da consulta ao web service via cep
                //Sucesso... o produto existe e continua o processaento.
                $cep_destino = str_replace('-', '', $this->input->POST('cep'));
                // Montando a URL para consultar o endereço.
                $url_endereco = 'https://viacep.com.br/ws/'; // Formato original do URL via CEP API: https://viacep.com.br/ws/01001000/json/
                $url_endereco .= $cep_destino;
                $url_endereco .= '/json/';

                $curl = curl_init();
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($curl, CURLOPT_URL, $url_endereco);
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // Se quiser utilizar o CURL para consumir uma API, terá que colocar esta instrução.


                $resultado = curl_exec($curl);

                $resultado = json_decode($resultado);

                if (isset($resultado->erro)) {
                    $retorno['erro'] = 3;
                    $retorno['mensagem'] = 'Não encontramos o CEP em nossa base de dados';
                    $retorno['retorno_endereco'] = '<p class="text-danger">Não encontramos o CEP em nossa base de dados</p>';
                } else {
                    $retorno['erro'] = 0;
                    $retorno['mensagem'] = 'Sucesso';
                    $retorno['retorno_endereco'] = $resultado->logradouro . '<br /> Bairro: ' .
                            $resultado->bairro . '<br />' .
                            $resultado->localidade . ' - ' . $resultado->uf . '<br />' .
                            'CEP: ' . $resultado->cep;
                }
                // Final da colsulta ao web service via cep
                // Início da consulta ao web service dos Correios
                // Montando a URL para os Correios exibir o valor do frete
                /*
                 * http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx?nCdEmpresa=08082650&sDsSenha=564321&sCepOrigem=70002900&sCepDestino=04547000&nVlPeso=1&nCdFormato=1&nVlComprimento=20&nVlAltura=20
                 * &nVlLargura=20&sCdMaoPropria=n&nVlValorDeclarado=0&sCdAvisoRecebimento=n&nCdServico=04510&nVlDiametro=0&StrRetorno=xml&nIndicaCalculo=3
                 */

                // Informações dos correios no banco de dadosb
                $config_correios = $this->Core_model->get_by_id('config_correios', array('config_id' => 1));

                // Para onde será enviado o produto.
                $cep_destino = $this->input->POST('cep');

                $url_correios = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.aspx?';
                $url_correios .= 'nCdEmpresa=08082650';
                $url_correios .= '&sDsSenha=564321';
                $url_correios .= '&sCepOrigem=' . str_replace('-', '', $config_correios->config_cep_origem);
                $url_correios .= '&sCepDestino=' . str_replace('-', '', $cep_destino);
                $url_correios .= '&nVlPeso=' . $produto->produto_peso;
                $url_correios .= '&nCdFormato=1'; // Não mexe no valor.
                $url_correios .= '&nVlComprimento=' . $produto->produto_comprimento;
                $url_correios .= '&nVlAltura=' . $produto->produto_altura;
                $url_correios .= '&nVlLargura=' . $produto->produto_largura;
                $url_correios .= '$sCdMaoPropria=n'; // Não mexe no valor.
                $url_correios .= '&nVlValorDeclarado=' . $config_correios->config_valor_declarado;
                $url_correios .= '&sCdAvisoRecebimento=n'; // Não mexe no valor.
                $url_correios .= '&nCdServico=' . $config_correios->config_codigo_pac;
                $url_correios .= '&nCdServico=' . $config_correios->config_codigo_sedex;
                $url_correios .= '&nVlDiametro=0'; // Não mexe no valor.
                $url_correios .= '&StrRetorno=xml'; // Não mexe no valor.
                $url_correios .= '&nIndicaCalculo=3'; // Não mexe no valor.
//                echo json_encode($url_correios);
//                exit();
                // Transformando o documento XML em um objeto
                $xml = simplexml_load_file($url_correios);
                $xml = json_encode($xml);

                $consulta = json_decode($xml);

                // Garantido que houve sucesso na consulta ao web services dos correios.
                if ($consulta->cServico[0]->Valor == '0,00') { // Dá resposta...
                    $retorno['erro'] = 3;
                    $retorno['retorno_endereco'] = 'Não foi possível calcular o frete. Tente mais tarde!';
                    exit();
                } else { // Sucesso... Valor a prazo gerado.
                    foreach ($consulta->cServico as $dados) {
                        $frete_calculado = '<p>' . $dados->Valor . ', Cod Serviço: ' . $dados->Codigo . '</p>';
                    }
                }
                $retorno['erro'] = 0;
                $retorno['retorno_endereco'] = $frete_calculado;
            }
        } else {
            //Erro de validação
            $retorno['erro'] = 5;
            $retorno['retorno_endereco'] = validation_errors();
        }
        echo json_encode($retorno);
    }

    /*
      bairro: "Conjunto Habitacional Ourinhos Caiuá"
      cep: "19915-180"
      complemento: ""
      ddd: "14"
      gia: "4959"
      ibge: "3534708"
      localidade: "Ourinhos"
      logradouro: "Rua Ester Serrano da Silva"
      siafi: "6795"
      uf: "SP"
     */
}
