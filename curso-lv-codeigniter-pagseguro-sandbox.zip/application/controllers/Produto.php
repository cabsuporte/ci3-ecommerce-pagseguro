<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Produto extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        
        $this->output->enable_profiler(FALSE);
    }

    public function index($produto_meta_link = NULL) {
        if (!$produto_meta_link || !$produto = $this->Produtos_model->get_by_id($produto_meta_link)) {
            redirect('/');
        } else {
            // Se der errado volta para página de formulário com msg de erro.
            $sistema = info_header_footer();
            
            $data = array(
                'titulo' => 'Detalhes do produto ' . $produto->produto_nome,
                'produto' => $produto, // O carregmaneto de dados deste objeto esta na linha 8.
                'sistema' => info_header_footer(),
                'produtos_destaques' => $this->Loja_model->get_produtos_destaques($sistema->sistema_produtos_destaques), // Produtos em destaques.
                'scripts' => array(
                    'js/mask/jquery.mask.min.js',
                    'js/mask/custom.js',
                    'js/add_produto.js',
                ),
            );

            $data['fotos_produtos'] = $this->Core_model->get_all('produtos_fotos', array('foto_produto_id' => $produto->produto_id));

//            echo '<pre>';
//            print_r($data);
//            exit();

            $this->load->view('site/layout/head', $data);
            $this->load->view('site/layout/_navbar');
            $this->load->view('site/produtos/index');
            $this->load->view('site/layout/footer');
        }
    }

}
