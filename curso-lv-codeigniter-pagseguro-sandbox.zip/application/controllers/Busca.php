<?php

defined('BASEPATH')OR exit('Menhuma ação permitida!');

class Busca extends CI_Controller {

//    public function __construct() {
//        parent::__construct();
//    }

    public function index() {

        $sistema = info_header_footer();
        $busca = html_escape($this->input->POST('busca'));

        $data = array(
            'sistema' => info_header_footer(),
            'titulo' => 'Busca pelo produto ' . (!empty($busca) ? $busca : 'Nenhum termo foi digitado!'),
            'termo_digitado' => (!empty($busca) ? $busca : 'Nenhum termo foi digitado!'),
        );

        if ($busca) {
            if ($produtos = $this->Produtos_model->get_all_by_busca($busca)) {
                $data['produtos'] = $produtos;
            }
        }

        $this->load->view('site/layout/head', $data);
        $this->load->view('site/layout/_navbar');
        $this->load->view('site/busca/index');
        $this->load->view('site/layout/footer');
    }

}
