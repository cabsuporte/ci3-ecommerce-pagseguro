<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida aqui!');

class Subcategorias extends CI_Controller {

    public function __construct() {
        parent::__construct();

//        if(!$this->ion_auth->logged_in()){
//            redirect('intranet/login');
//        }
    }

    public function index() {
        $data = array(
            'titulo' => 'Subcategoria cadastradas',
            'subtitulo' => 'Listando todas Subcategoria cadastradas no banco de dados.',
            'icone_view' => 'fa fa-list',
            'subcategorias' => $this->Subcategorias_model->get_all(),
            'styles' => array(
                'assets/bundles/datatables/datatables.min.css',
                'assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css',
            ),
            'scripts' => array(
                'assets/bundles/datatables/datatables.min.js',
                'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js',
                'assets/bundles/jquery-ui/jquery-ui.min.js',
                'assets/js/page/datatables.js',
            ),
        );

        $this->load->view('intranet/layout/header', $data);
        $this->load->view('intranet/layout/_navbar');
        $this->load->view('intranet/layout/_sidebar');
        $this->load->view('intranet/subcategorias/index');
        $this->load->view('intranet/layout/footer');
    }

    public function Core($subcategoria_id = NULL) {

        $subcategoria_id = (int) $subcategoria_id; // type cast = força a variavel ser inteiro.

        if (!$subcategoria_id) {
            // Inclusão de dados
            $this->form_validation->set_rules('subcategoria_nome', 'NOME DA SUBCATEGORIA',
                    'trim|required|min_length[2]|max_length[50]|is_unique[subcategorias.subcategoria_nome]');
            $this->form_validation->set_rules('categoria_id', 'CATEGORIA', 'trim|required');

            if ($this->form_validation->run()) {
                // Se der certo segue adiante
                $data = elements(
                        array(
                            'subcategoria_nome',
                            'subcategoria_ativa',
                            'categoria_id',
                        ), $this->input->POST()
                );
                $data['subcategoria_meta_link'] = url_amigavel($data['subcategoria_nome']);

                $data = html_escape($data);
                $this->Core_model->INSERIR('subcategorias', $data);
                redirect('intranet/subcategorias/');
            } else {
                // Se der errado volta para página de formulário com msg de erro.
                $data = array(
                    'titulo' => 'Inserir Subcategoria',
                    'subtitulo' => 'Inserir Subcategoria no banco de dados.',
                    'icone_view' => 'fa fa-list',
                    'categorias' => $this->Core_model->get_all('categorias', array('categoria_ativa' => 1)),
                );

                $this->load->view('intranet/layout/header', $data);
                $this->load->view('intranet/layout/_navbar');
                $this->load->view('intranet/layout/_sidebar');
                $this->load->view('intranet/subcategorias/core');
                $this->load->view('intranet/layout/footer');
            }
        } else {
            if (!$objeto_subcategoria_id = $this->Core_model->get_by_id('subcategorias', array('subcategoria_id' => $subcategoria_id))) {
                $this->session->set_flashdata('error', 'Subcategoria não encontrada!');
                redirect('intranet/subcategorias/');
            } else {
                // Edição de dados
                $this->form_validation->set_rules('subcategoria_nome', 'NOME DA SUBCATEGORIA',
                        'trim|required|min_length[2]|max_length[50]|callback_Check_Subcategoria_Nome');
                $this->form_validation->set_rules('categoria_id', 'CATEGORIA', 'trim|required');

                if ($this->form_validation->run()) {
                    // Se der certo segue adiante
                    $data = elements(
                            array(
                                'subcategoria_nome',
                                'subcategoria_ativa',
                                'categoria_id',
                            ), $this->input->POST()
                    );
                    $data['subcategoria_meta_link'] = url_amigavel($data['subcategoria_nome']);

                    $data = html_escape($data);
                    $this->Core_model->ATUALIZAR('subcategorias', $data, array('subcategoria_id' => $subcategoria_id));
                    redirect('intranet/subcategorias');
                } else {
                    // Se der errado volta para página de formulário com msg de erro.
                    $data = array(
                        'titulo' => 'Editar Subcategoria',
                        'subtitulo' => 'Editar Subcategoria no banco de dados.',
                        'icone_view' => 'fa fa-list',
                        'categorias' => $this->Core_model->get_all('categorias', array('categoria_ativa' => 1)),
                        'subcategoria' => $objeto_subcategoria_id, // Essa variavel, é um Array de Objetos.
                    );

                    $this->load->view('intranet/layout/header', $data);
                    $this->load->view('intranet/layout/_navbar');
                    $this->load->view('intranet/layout/_sidebar');
                    $this->load->view('intranet/subcategorias/core');
                    $this->load->view('intranet/layout/footer');
                }
            }
        }
    }

    public function Check_Subcategoria_Nome($subcategoria_nome) {
        $subcategoria_id = $this->input->POST('subcategoria_id');

        if ($this->Core_model->get_by_id('subcategorias',
                        array(
                            'subcategoria_nome' => $subcategoria_nome,
                            'subcategoria_id !=' => $subcategoria_id,
                ))) {
            $this->form_validation->set_message('Check_Subcategoria_Nome', 'Esta Subcategoria já existe no bando de dados!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function Del($subcategoria_id = NULL) {
        $subcategoria_id = (int) $subcategoria_id; // type cast = força a variavel ser inteiro.
        // Instrução para verificar se existe bug no banco e categoria existe, caso não, não irá deletar.
        if (!$subcategoria_id || !$this->Core_model->get_by_id('subcategorias', array('subcategoria_id' => $subcategoria_id))) {
            $this->session->set_flashdata('error', 'Subcategoria não encontrada!');
            redirect('intranet/subcategorias');
        }
        // Instrução para verificar se está ativa, caso sim, não irá deletar.
        if ($this->Core_model->get_by_id('subcategorias', array('subcategoria_id' => $subcategoria_id, 'subcategoria_ativa' => 1))) {
            $this->session->set_flashdata('error', 'Não é possivel EXCLUIR uma Subcategoria que esta ativa!');
            redirect('intranet/subcategorias');
        }
        // Instrução de exclusão da linha no banco.
        $this->Core_model->DELETAR('subcategorias', array('subcategoria_id' => $subcategoria_id));
        redirect('intranet/subcategorias');
    }

}
