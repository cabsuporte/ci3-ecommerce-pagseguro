<?php

defined('BASEPATH') OR exit('Ação não permitida!');

class Sistema extends CI_Controller {

//    public function __construct() {
//        parent::__construct();
//
//        if (!$this->ion_auth->logged_in()) { // Com esta condição, não a como entrar na página HOME.
//            redirect('login');
//        }
//        
//        if (!$this->ion_auth->is_admin()) {
//            $this->session->set_flashdata('error', 'Você não tem permissão para acessar esse Menu');
//            redirect('/');
//        }
//    }

    public function index() {

        $this->form_validation->set_rules('sistema_razao_social', 'Razão Social', 'trim|required|min_length[5]|max_length[145]');
        $this->form_validation->set_rules('sistema_nome_fantasia', 'Nome Fantasia', 'trim|required|min_length[5]|max_length[145]');
        $this->form_validation->set_rules('sistema_cnpj', 'CNPJ', 'trim|required|exact_length[18]');
        $this->form_validation->set_rules('sistema_ie', 'Inscrição Estadual', 'trim|required|max_length[25]');
        $this->form_validation->set_rules('sistema_telefone_fixo', 'Telefone fixo', 'trim|required|max_length[14]');
        $this->form_validation->set_rules('sistema_telefone_movel', 'Celular', 'trim|required|max_length[15]');
        $this->form_validation->set_rules('sistema_cep', 'CEP', 'trim|required|exact_length[9]');
        $this->form_validation->set_rules('sistema_endereco', 'Endereço', 'trim|required|min_length[5]|max_length[145]');
        $this->form_validation->set_rules('sistema_numero', 'Número', 'trim|required|min_length[2]|max_length[10]');
        $this->form_validation->set_rules('sistema_cidade', 'Cidade', 'trim|required|min_length[4]|max_length[50]');
        $this->form_validation->set_rules('sistema_estado', 'UF', 'trim|required|exact_length[2]');
        $this->form_validation->set_rules('sistema_site_url', 'URL do site', 'trim|required|valid_url|max_length[100]');
        $this->form_validation->set_rules('sistema_email', 'E-mail', 'trim|required|valid_email|max_length[100]');
        $this->form_validation->set_rules('sistema_produtos_destaques', 'QTD DE PRODUTOS EM DESTQUE', 'trim|required');

        if ($this->form_validation->run()) {
//            echo'<pre>';
//            print_r($this->input->POST());
//            echo '</pre>';
//            exit();

            $data = elements(
                    array(
                        'sistema_razao_social',
                        'sistema_nome_fantasia',
                        'sistema_cnpj',
                        'sistema_ie',
                        'sistema_telefone_fixo',
                        'sistema_telefone_movel',
                        'sistema_cep',
                        'sistema_endereco',
                        'sistema_numero',
                        'sistema_cidade',
                        'sistema_estado',
                        'sistema_site_url',
                        'sistema_email',
                        'sistema_produtos_destaques',
                    ), $this->input->POST()
            );
            $data['sistema_estado'] = strtoupper($data['sistema_estado']); // Manter o caracter em maiusculo.
            //Sanitizar dados
            $data = html_escape($data);

            $this->Core_model->ATUALIZAR('sistema', $data, array('sistema_id' => 1));
            redirect('intranet/sistema');
        } else {
            // Erro de nevagação

            $data = array(
                'titulo' => 'Editar informações',
                'subtitulo' => 'Editando as informações do sistema no banco de dados.',
                'icone_view' => 'fa fa-settings',
                'sistema' => $this->Core_model->get_by_id('sistema', array('sistema_id' => 1)),
                'scripts' => array(
                    'assets/js/mask/jquery.mask.min.js',
                    'assets/js/mask/custom.js',
                ),
            );

            $this->load->view('intranet/layout/header', $data);
            $this->load->view('intranet/layout/_navbar');
            $this->load->view('intranet/layout/_sidebar');
            $this->load->view('intranet/sistema/index');
            $this->load->view('intranet/layout/footer');
        }
    }

    public function Correios() {

        $this->form_validation->set_rules('config_cep_origem', 'CEP de ORIGEM', 'trim|required|exact_length[9]');
        $this->form_validation->set_rules('config_codigo_pac', 'COD do serviço PAC', 'trim|required|exact_length[5]');
        $this->form_validation->set_rules('config_codigo_sedex', 'COD do serviço SEDEX', 'trim|required|exact_length[5]');
        $this->form_validation->set_rules('config_somar_frete', 'SOMAR ao FRETE', 'trim|required');
        $this->form_validation->set_rules('config_valor_declarado', 'VALOR DECLARADO', 'trim|required');

        if ($this->form_validation->run()) {
//            echo'<pre>';
//            print_r($this->input->POST());
//            echo '</pre>';
//            exit();

            $data = elements(
                    array(
                        'config_cep_origem',
                        'config_codigo_pac',
                        'config_codigo_sedex',
                        'config_somar_frete',
                        'config_valor_declarado',
                    ), $this->input->POST()
            );
            // Remove a vírgula
            $data['config_somar_frete'] = str_replace(',', '', $data['config_somar_frete']);
            $data['config_valor_declarado'] = str_replace(',', '', $data['config_valor_declarado']);
          
            //Sanitizar dados
            $data = html_escape($data);

            $this->Core_model->ATUALIZAR('config_correios', $data, array('config_id' => 1));
            redirect('intranet/sistema/correios');
        } else {
            // Erro de nevagação

            $data = array(
                'titulo' => 'Editar informações dos Correios',
                'subtitulo' => 'Editando as informações dos Correios no banco de dados.',
                'icone_view' => 'fa fa-settings',
                'correio' => $this->Core_model->get_by_id('config_correios', array('config_id' => 1)),
                'scripts' => array(
                    'assets/js/mask/jquery.mask.min.js',
                    'assets/js/mask/custom.js',
                ),
            );

            $this->load->view('intranet/layout/header', $data);
            $this->load->view('intranet/layout/_navbar');
            $this->load->view('intranet/layout/_sidebar');
            $this->load->view('intranet/sistema/correios');
            $this->load->view('intranet/layout/footer');
        }
    }
    
    public function Pagseguro() {

        $this->form_validation->set_rules('config_email', 'EMAIL', 'trim|required|valid_email');
        $this->form_validation->set_rules('config_token', 'TOKEN', 'trim|required|max_length[100]');

        if ($this->form_validation->run()) {
//            echo'<pre>';
//            print_r($this->input->POST());
//            echo '</pre>';
//            exit();

            $data = elements(
                    array(
                        'config_email',
                        'config_token',
                        'config_ambiente',
                    ), $this->input->POST()
            );
          
            //Sanitizar dados
            $data = html_escape($data);

            $this->Core_model->ATUALIZAR('config_pagseguro', $data, array('config_id' => 1));
            redirect('intranet/sistema/pagseguro');
        } else {
            // Erro de nevagação

            $data = array(
                'titulo' => 'Editar informações do PagSeguro',
                'subtitulo' => 'Editando as informações do PagSeguro no banco de dados.',
                'icone_view' => 'fa fa-settings',
                'pagseguro' => $this->Core_model->get_by_id('config_pagseguro', array('config_id' => 1)),
            );

            $this->load->view('intranet/layout/header', $data);
            $this->load->view('intranet/layout/_navbar');
            $this->load->view('intranet/layout/_sidebar');
            $this->load->view('intranet/sistema/pagseguro');
            $this->load->view('intranet/layout/footer');
        }
    }

}
