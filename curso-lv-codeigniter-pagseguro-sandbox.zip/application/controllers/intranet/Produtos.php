<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida aqui!');

class Produtos extends CI_Controller {

    public function index() {
        $data = array(
            'titulo' => 'Lista de Produtos cadastrados',
            'subtitulo' => 'Listando todas Subcategoria cadastradas no banco de dados.',
            'icone_view' => 'fa fa-box',
            'produtos' => $this->Produtos_model->Get_All(),
            'styles' => array(
                'assets/bundles/datatables/datatables.min.css',
                'assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css',
            ),
            'scripts' => array(
                'assets/bundles/datatables/datatables.min.js',
                'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js',
                'assets/bundles/jquery-ui/jquery-ui.min.js',
                'assets/js/page/datatables.js',
            ),
        );

        $this->load->view('intranet/layout/header', $data);
        $this->load->view('intranet/layout/_navbar');
        $this->load->view('intranet/layout/_sidebar');
        $this->load->view('intranet/produtos/index');
        $this->load->view('intranet/layout/footer');
    }

    public function Core($produto_id = NULL) {

        $produto_id = (int) $produto_id; // type cast = força a variavel ser inteiro.

        if (!$produto_id) {
            // Inclusão de dados
            $this->form_validation->set_rules('produto_nome', 'NOME DA PRODUTO',
                    'trim|required|min_length[2]|max_length[50]');
            $this->form_validation->set_rules('produto_categoria_id', 'CATEGORIA DO PRODUTO', 'trim|required');
            $this->form_validation->set_rules('produto_subcategoria_id', 'SUBCATEGORIA DO PRODUTO', 'trim|required');
            $this->form_validation->set_rules('produto_marca_id', 'MARCA DO PRODUTO', 'trim|required');
//            $this->form_validation->set_rules('produto_peso', 'PESO DO PRODUTO', 'trim|required|integer');
//            $this->form_validation->set_rules('produto_altura', 'ALTURA DO PRODUTO', 'trim|required|integer');
//            $this->form_validation->set_rules('produto_largura', 'LARGURA DO PRODUTO', 'trim|required|integer');
//            $this->form_validation->set_rules('produto_comprimento', 'COMPRIMENTO DO PRODUTO', 'trim|required|integer');
            $this->form_validation->set_rules('produto_valor', 'VALOR DO PRODUTO', 'trim|required');
            $this->form_validation->set_rules('produto_controlar_estoque', 'CONTROLE DE ESTOQUE DO PRODUTO', 'trim|required|integer');
            $this->form_validation->set_rules('produto_quantidade_estoque', 'QUANTIDADE DO PRODUTO', 'trim|required|integer');
            $this->form_validation->set_rules('produto_descricao', 'DESCRIÇÃO DO PRODUTO', 'trim|required|min_length[10]|max_length[500]');

            $foto_produto = $this->input->POST('fotos_produtos');

            if (!$foto_produto) {
                $this->form_validation->set_rules('fotos_produtos', 'Imagens do produto', 'required');
            }

            if ($this->form_validation->run()) {
                // Se der certo segue adiante
                $data = elements(
                        array(
                            'produto_nome',
                            'produto_ativo',
                            'produto_categoria_id',
                            'produto_subcategoria_id',
                            'produto_marca_id',
                            'produto_peso',
                            'produto_altura',
                            'produto_largura',
                            'produto_comprimento',
                            'produto_valor',
                            'produto_destaque',
                            'produto_controlar_estoque',
                            'produto_quantidade_estoque',
                            'produto_descricao',
                        ), $this->input->POST()
                );
                // Remove a virgula do valor
                $data['produto_valor'] = str_replace(',', '', $data['produto_valor']);
                // Trabalha o metalink do produto
                $data['produto_meta_link'] = url_amigavel($data['produto_nome']);
                // Codigo gerado
                $data['produto_codigo'] = $this->input->POST('produto_codigo');

                $data = html_escape($data);
                $this->Core_model->INSERIR('produtos', $data, TRUE);

                // Recupera o ultimo ID inserido.
                $produto_id = $this->session->userdata('last_id');

                // Recupera valor do post que inputa as fotos
                $foto_produto = $this->input->POST('fotos_produtos');

                if ($foto_produto) {
                    $total_fotos = count($foto_produto);

                    for ($i = 0; $i < $total_fotos; $i++) {
                        $data = array(
                            'foto_produto_id' => $produto_id,
                            'foto_caminho' => $foto_produto[$i],
                        );
                        $this->Core_model->INSERIR('produtos_fotos', $data);
                    }
                }
                redirect('intranet/produtos/');
            } else {
                // Se der errado volta para página de formulário com msg de erro.
                $data = array(
                    'titulo' => 'Cadastrar Produtos',
                    'subtitulo' => 'Cadastrar Produtos no banco de dados.',
                    'icone_view' => 'fa fa-list',
                    'marcas' => $this->Core_model->get_all('marcas', array('marca_ativa' => 1)),
                    'categorias' => $this->Core_model->get_all('categorias', array('categoria_ativa' => 1)),
                    'subcategorias' => $this->Core_model->get_all('subcategorias', array('subcategoria_ativa' => 1)),
                    'codigo_gerado' => $this->Core_model->generate_unique_code('produtos', 'numeric', 8, 'produto_codigo'),
                    'styles' => array(
                        'assets/jquery-upload-file/css/uploadfile.css',
                    ),
                    'scripts' => array(
                        'assets/js/page/sweetalert2.min.js',
                        'assets/jquery-upload-file/js/jquery.uploadfile.min.js',
                        'assets/jquery-upload-file/js/produtos.js',
                        'assets/js/mask/jquery.mask.min.js',
                        'assets/js/mask/custom.js',
                    ),
                );

                $this->load->view('intranet/layout/header', $data);
                $this->load->view('intranet/layout/_navbar');
                $this->load->view('intranet/layout/_sidebar');
                $this->load->view('intranet/produtos/core');
                $this->load->view('intranet/layout/footer');
            }
        } else { // Edição de dados
            if (!$objeto_produto = $this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))) {
                $this->session->set_flashdata('error', 'Produto não encontrado!');
                redirect('intranet/produtos/');
            } else {
                $this->form_validation->set_rules('produto_nome', 'NOME DA PRODUTO',
                        'trim|required|min_length[2]|max_length[50]');
                $this->form_validation->set_rules('produto_categoria_id', 'CATEGORIA DO PRODUTO', 'trim|required');
                $this->form_validation->set_rules('produto_subcategoria_id', 'SUBCATEGORIA DO PRODUTO', 'trim|required');
                $this->form_validation->set_rules('produto_marca_id', 'MARCA DO PRODUTO', 'trim|required');
//                $this->form_validation->set_rules('produto_peso', 'PESO DO PRODUTO', 'trim|required|integer');
//                $this->form_validation->set_rules('produto_altura', 'ALTURA DO PRODUTO', 'trim|required|integer');
//                $this->form_validation->set_rules('produto_largura', 'LARGURA DO PRODUTO', 'trim|required|integer');
//                $this->form_validation->set_rules('produto_comprimento', 'COMPRIMENTO DO PRODUTO', 'trim|required|integer');
                $this->form_validation->set_rules('produto_valor', 'VALOR DO PRODUTO', 'trim|required');
                $this->form_validation->set_rules('produto_controlar_estoque', 'CONTROLE DE ESTOQUE DO PRODUTO', 'trim|required|integer');
                $this->form_validation->set_rules('produto_quantidade_estoque', 'QUANTIDADE DO PRODUTO', 'trim|required|integer');
                $this->form_validation->set_rules('produto_descricao', 'DESCRIÇÃO DO PRODUTO', 'trim|required|min_length[10]|max_length[500]');

                if ($this->form_validation->run()) {
                    // Se der certo segue adiante
                    $data = elements(
                            array(
                                'produto_nome',
                                'produto_ativo',
                                'produto_categoria_id',
                                'produto_subcategoria_id',
                                'produto_marca_id',
                                'produto_peso',
                                'produto_altura',
                                'produto_largura',
                                'produto_comprimento',
                                'produto_valor',
                                'produto_destaque',
                                'produto_controlar_estoque',
                                'produto_quantidade_estoque',
                                'produto_descricao',
                            ), $this->input->POST()
                    );
                    // Remove a virgula do valor
                    $data['produto_valor'] = str_replace(',', '', $data['produto_valor']);
                    // Trabalha o metalink do produto
                    $data['produto_meta_link'] = url_amigavel($data['produto_nome']);

                    $data = html_escape($data);
                    $this->Core_model->ATUALIZAR('produtos', $data, array('produto_id' => $produto_id));

                    // Excluir imagens atingas do produto.
                    $this->Core_model->DELETAR('produtos_fotos', array('foto_produto_id' => $produto_id));
                    // Recupera valor do post que inputa as fotos
                    $foto_produto = $this->input->POST('fotos_produtos');
                    if ($foto_produto) {
                        $total_fotos = count($foto_produto);
                        for ($i = 0; $i < $total_fotos; $i++) {
                            $data = array(
                                'foto_produto_id' => $produto_id,
                                'foto_caminho' => $foto_produto[$i],
                            );
                            $this->Core_model->INSERIR('produtos_fotos', $data);
                        }
                    }
                    redirect('intranet/produtos');
                } else {
                    // Se der errado volta para página de formulário com msg de erro.
                    $data = array(
                        'titulo' => 'Editar Produtos',
                        'subtitulo' => 'Editar Produto no banco de dados.',
                        'icone_view' => 'fa fa-list',
                        'produto' => $objeto_produto, // Usa Metodo da classe Core_model
                        'marcas' => $this->Core_model->get_all('marcas', array('marca_ativa' => 1)),
                        'categorias' => $this->Core_model->get_all('categorias', array('categoria_ativa' => 1)),
                        'subcategorias' => $this->Core_model->get_all('subcategorias', array('subcategoria_ativa' => 1)),
                        'foto_produto' => $this->Core_model->get_all('produtos_fotos', array('foto_produto_id' => $produto_id)),
                        'styles' => array(
                            'assets/jquery-upload-file/css/uploadfile.css',
                        ),
                        'scripts' => array(
                            'assets/js/page/sweetalert2.min.js',
                            'assets/jquery-upload-file/js/jquery.uploadfile.min.js',
                            'assets/jquery-upload-file/js/produtos.js',
                            'assets/js/mask/jquery.mask.min.js',
                            'assets/js/mask/custom.js',
                        ),
                    );

                    $this->load->view('intranet/layout/header', $data);
                    $this->load->view('intranet/layout/_navbar');
                    $this->load->view('intranet/layout/_sidebar');
                    $this->load->view('intranet/produtos/core');
                    $this->load->view('intranet/layout/footer');
                }
            }
        }
    }

    public function Check_Produto_Nome($produto_nome) {
        $produto_id = $this->input->POST('produto_id');

        if (!$produto_id) { // Cadastrando
            if ($this->Core_model->get_by_id('produtos', array('produto_nome' => $produto_nome,))) {
                $this->form_validation->set_message('Check_Produto_Nome', 'Este PRODUTO já existe no bando de dados!');
                return FALSE;
            } else {
                return TRUE;
            }
        } else { // Editando
            if ($this->Core_model->get_by_id('produtos',
                            array(
                                'produto_nome' => $produto_nome,
                                'produto_id !=' => $produto_id,
                    ))) {
                $this->form_validation->set_message('Check_Produto_Nome', 'Este PRODUTO já existe no bando de dados!');
                return FALSE;
            } else {
                return TRUE;
            }
        }
    }

    public function Uploads() {
        $config['upload_path'] = 'assets/uploads/produtos/';
        $config['allowed_types'] = 'jpg|png|jpeg|gif';
        $config['max_size'] = '1024';
        $config['max_width'] = '2048';
        $config['max_height'] = '2048';
        $config['encrypt_name'] = TRUE;
        $config['max_filename'] = '200';
        $config['file_ext_tolower'] = TRUE;

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('fotos_produtos')) {
            $data = array(
                'uploaded_data' => $this->upload->data(),
                'mensagem' => 'Imagem enviada com sucesso!',
                'foto_caminho' => $this->upload->data('file_name'),
                'erro' => 0,
            );
            // Resize image config
            $config['image_library'] = 'gd2'; // Intancia biblioteca para renomear a foto.
            $config['source_image'] = 'assets/uploads/produtos/' . $this->upload->data('file_name');
            $config['new_image'] = 'assets/uploads/produtos/pequena/' . $this->upload->data('file_name');
            $config['width'] = 300;
            $config['height'] = 300;
            // Chama a biblioteca
            $this->load->library('image_lib', $config);
            // Faz o resize
//            $this->image_lib->resize();

            if (!$this->image_lib->resize()) {
                $data['erro'] = $this->image_lib->display_errors();
            }
        } else {
            $data = array(
                'mensagem' => $this->upload->display_errors(),
                'erro' => 5,
            );
        }
        echo json_encode($data);
    }

    public function Del($produto_id = NULL) {
        $produto_id = (int) $produto_id; // type cast = força a variavel ser inteiro.
        // Instrução para verificar se existe bug no banco e categoria existe, caso não, não irá deletar.
        if (!$produto_id || !$this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id))) {
            $this->session->set_flashdata('error', 'Produto não encontrado!');
            redirect('intranet/produtos');
        }
        // Instrução para verificar se está ativo, caso sim, não irá deletar.
        if ($this->Core_model->get_by_id('produtos', array('produto_id' => $produto_id, 'produto_ativo' => 1))) {
            $this->session->set_flashdata('error', 'Não é possivel EXCLUIR um PRODUTO que esta ativo!');
            redirect('intranet/produtos');
        }
        // Recupera a fotos do produto antes da exclusão.
        $foto_produto = $this->Core_model->get_all('produtos_fotos', array('foto_produto_id' => $produto_id));
        // Instrução de exclusão da linha no banco.
        $this->Core_model->DELETAR('produtos', array('produto_id' => $produto_id));
        // Elimina as fotos do produto que estão relacionados ao produto cadastrado.
        if ($foto_produto) {
            foreach ($foto_produto as $foto) {
                $foto_grande = FCPATH . 'assets/uploads/produtos/' . $foto->foto_caminho;
                $foto_pqna = FCPATH . 'assets/uploads/produtos/pequena/' . $foto->foto_caminho;
                // Ezclui as imagens
                if (file_exists($foto_grande) && file_exists($foto_pqna)) {
                    unlink($foto_pqna);
                    unlink($foto_grande);
                }
            }
        }
        redirect('intranet/produtos');
    }

}
