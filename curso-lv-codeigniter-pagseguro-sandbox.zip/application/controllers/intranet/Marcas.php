<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida aqui!');

class Marcas extends CI_Controller {

    public function index() {

        $data = array(
            'titulo' => 'Marcas cadastrados',
            'subtitulo' => 'Listando todos Marcas cadastradas no banco de dados.',
            'icone_view' => 'fa fa-bookmark',
            'marcas' => $this->Core_model->get_all('marcas'),
            'styles' => array(
                'assets/bundles/datatables/datatables.min.css',
                'assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css',
            ),
            'scripts' => array(
                'assets/bundles/datatables/datatables.min.js',
                'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js',
                'assets/bundles/jquery-ui/jquery-ui.min.js',
                'assets/js/page/datatables.js',
            ),
        );

        $this->load->view('intranet/layout/header', $data);
        $this->load->view('intranet/layout/_navbar');
        $this->load->view('intranet/layout/_sidebar');
        $this->load->view('intranet/marcas/index');
        $this->load->view('intranet/layout/footer');
    }

    public function Core($marca_id = NULL) {

//        if (!$this->ion_auth->is_admin()) {
//            $this->session->set_flashdata('error', 'Você não tem permissão para CADASTRAR ou EDITAR');
//            redirect($this->router->fetch_class());
//        }

        if (!$marca_id) {
            // Cadastrando
            $this->form_validation->set_rules('marca_nome', 'O nome da Marca', 'trim|required|max_length[50]|is_unique[marcas.marca_nome]');

            if ($this->form_validation->run()) {
                $data = elements(
                        array(
                            'marca_nome',
                            'marca_ativa',
                        ), $this->input->POST()
                );
                // Criando met-link com função URL amigável
                $data['marca_meta_link'] = url_amigavel($data['marca_nome']);

                $data = html_escape($data);
                $this->Core_model->INSERIR('marcas', $data);
                redirect('intranet/marcas/');
            } else {
                // Erro de validação
                $data = array(
                    'titulo' => 'Cadastrar Marcas',
                    'subtitulo' => 'Cadastrar Marcas no banco de dados.',
                    'icone_view' => 'fa fa-bookmark',
                );

//                    echo '<pre>';
//                    print_r($data['forma']);
//                    echo '</pre>';
//                    exit();

                $this->load->view('intranet/layout/header', $data);
                $this->load->view('intranet/layout/_navbar');
                $this->load->view('intranet/layout/_sidebar');
                $this->load->view('intranet/marcas/core');
                $this->load->view('intranet/layout/footer');
            }
        } else {
            if (!$this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id))) { // Essa condição verifica se a o item existe no banco caso não, apresenta erro.
                $this->session->set_flashdata('error', 'Marca não encontrada!');
                redirect($this->router->fetch_class());
            } else {
                // Editando
                $this->form_validation->set_rules('marca_nome', 'MARCA',
                        'trim|required|max_length[50]|callback_check_marcas');

                if ($this->form_validation->run()) {
                    $data = elements(
                            array(
                                'marca_nome',
                                'marca_ativa',
                            ), $this->input->POST()
                    );
                    // Criando met-link com função URL amigável
                    $data['marca_meta_link'] = url_amigavel($data['marca_nome']);

                    $data = html_escape($data);
                    $this->Core_model->ATUALIZAR('marcas', $data, array('marca_id' => $marca_id));
                    redirect('intranet/marcas/');
                } else {
                    // Erro de validação
                    $data = array(
                        'titulo' => 'Editar Marcas',
                        'subtitulo' => 'Editar MARCAS cadastradas no banco de dados.',
                        'icone_view' => 'fa fa-bookmark',
                        'marca' => $this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id)),
                    );

//                    echo '<pre>';
//                    print_r($data['forma']);
//                    echo '</pre>';
//                    exit();

                    $this->load->view('intranet/layout/header', $data);
                    $this->load->view('intranet/layout/_navbar');
                    $this->load->view('intranet/layout/_sidebar');
                    $this->load->view('intranet/marcas/core');
                    $this->load->view('intranet/layout/footer');
                }
            }
        }
    }

    public function Detalhes($marca_id = NULL) {
        if ($marca_id) {
            $data = array(
                'titulo' => 'Detalhe da Marca',
                'subtitulo' => 'Detalhe da MARCA cadastrada no banco de dados.',
                'icone_view' => 'fa fa-bookmark',
                'marca' => $this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id)),
            );

            $this->load->view('intranet/layout/header', $data);
            $this->load->view('intranet/layout/_navbar');
            $this->load->view('intranet/layout/_sidebar');
            $this->load->view('intranet/marcas/details');
            $this->load->view('intranet/layout/footer');
        } else {
            $this->session->set_flashdata('error', 'Aconteceu um erro na exibição do detalhe da MARCA, tente mais tarde!');
            redirect('intranet/marcas');
        }
    }

    public function check_marcas($marca_nome) { // Aqui nesta função verifica se o nome é duplicidade.
        $marca_id = $this->input->POST('marca_id');

        if (!$marca_id) { // Verifica se o id esta sendo passado, se não, é para cadastro e não editar!
            // Cadastrando
            if ($this->Core_model->get_by_id('marcas', array('marca_nome' => $marca_nome))) {
                $this->form_validation->set_message('check_marcas', 'Essa MARCA já existe!');
                return FALSE;
            } else {
                return TRUE;
            }
        } else {
            if ($this->Core_model->get_by_id('marcas',
                            array('marca_nome' => $marca_nome,
                                'marca_id !=' => $marca_id))) {
                $this->form_validation->set_message('check_marcas', 'Essa MARCA já existe!');
                return FALSE;
            } else {
                return TRUE;
            }
        }
    }

    public function Del($marca_id = NULL) {

//        if (!$this->ion_auth->is_admin()) {
//            $this->session->set_flashdata('error', 'Você não tem permissão para EXCLUIR os itens deste menu');
//            redirect($this->router->fetch_class());
//        }
        // Condição que verifica se existe no banco.
        $marca_id = (int) $marca_id;

        if (!$marca_id || !$this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id))) {
            $this->session->set_flashdata('error', 'MARCA não encontrada!');
            redirect('intranet/marcas/');
        }

        if ($this->Core_model->get_by_id('marcas', array('marca_id' => $marca_id, 'marca_ativa' => 1))) {
            $this->session->set_flashdata('error', 'Não é possível excluir uma marca ATIVA.');
            redirect('intranet/marcas/');
        }
        
        // Instrução de exclusão da linha no banco.
        $this->Core_model->DELETAR('marcas', array('marca_id' => $marca_id));
        redirect('intranet/marcas/');
    }

}
