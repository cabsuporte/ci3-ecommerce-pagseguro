<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida aqui!');

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();

        if (!$this->ion_auth->logged_in()) { // Com esta condição, não a como entrar na página USUARIOS.
            redirect('intranet/login');
        }
    }

    public function index() {

        $this->load->view('intranet/layout/header');
        $this->load->view('intranet/layout/_navbar');
        $this->load->view('intranet/layout/_sidebar');
        $this->load->view('intranet/home/index');
        $this->load->view('intranet/layout/footer');
    }

}
