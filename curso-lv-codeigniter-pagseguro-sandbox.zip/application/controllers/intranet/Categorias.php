<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida aqui!');

class Categorias extends CI_Controller {

    public function __construct() {
        parent::__construct();

//        if(!$this->ion_auth->logged_in()){
//            redirect('intranet/login');
//        }
    }

    public function index() {
        $data = array(
            'titulo' => 'Categorias cadastradas',
            'subtitulo' => 'Listando todas Categorias cadastradas no banco de dados.',
            'icone_view' => 'fa fa-list',
            'categorias' => $this->Core_model->get_all('categorias'),
            'styles' => array(
                'assets/bundles/datatables/datatables.min.css',
                'assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css',
            ),
            'scripts' => array(
                'assets/bundles/datatables/datatables.min.js',
                'assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js',
                'assets/bundles/jquery-ui/jquery-ui.min.js',
                'assets/js/page/datatables.js',
            ),
        );

        $this->load->view('intranet/layout/header', $data);
        $this->load->view('intranet/layout/_navbar');
        $this->load->view('intranet/layout/_sidebar');
        $this->load->view('intranet/categorias/index');
        $this->load->view('intranet/layout/footer');
    }

    public function Core($categoria_id = NULL) {

        $categoria_id = (int) $categoria_id; // type cast = força a variavel ser inteiro.

        if (!$categoria_id) {
            // Inclusão de dados
            $this->form_validation->set_rules('categoria_nome', 'NOME DA CATEGORIA',
                    'trim|required|min_length[2]|max_length[50]|is_unique[categorias.categoria_nome]');

            if ($this->form_validation->run()) {
                // Se der certo segue adiante
                $data = elements(
                        array(
                            'categoria_nome',
                            'categoria_ativa',
                        ), $this->input->POST()
                );
                $data['categoria_meta_link'] = url_amigavel($data['categoria_nome']);

                $data = html_escape($data);
                $this->Core_model->INSERIR('categorias', $data);
                redirect('intranet/categorias/');
            } else {
                // Se der errado volta para página de formulário com msg de erro.
                $data = array(
                    'titulo' => 'Inserir Categorias',
                    'subtitulo' => 'Inserir Categorias no banco de dados.',
                    'icone_view' => 'fa fa-list',
                );

                $this->load->view('intranet/layout/header', $data);
                $this->load->view('intranet/layout/_navbar');
                $this->load->view('intranet/layout/_sidebar');
                $this->load->view('intranet/categorias/core');
                $this->load->view('intranet/layout/footer');
            }
        } else {
            if (!$objeto_categoria_id = $this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))) {
                $this->session->set_flashdata('error', 'Categoria não encontrada!');
                redirect('intranet/categorias/');
            } else {
                // Edição de dados
                $this->form_validation->set_rules('categoria_nome', 'NOME DA CATEGORIA',
                        'trim|required|min_length[2]|max_length[50]|callback_Check_Categoria_Nome');

                if ($this->form_validation->run()) {
                    // Se der certo segue adiante

                    if ($this->input->POST('subcategoria_ativa') == 0) {
                        // Definir proibição de desativação.
                        if ($this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))) {
                            $this->session->set_flashdata('error', 'Essa CATEGORIA não pode ser desativada, pois está vinculada a uma SUBCATEGORIA!');
                            redirect('intranet/categorias');
                        }
                    }

                    $data = elements(
                            array(
                                'categoria_nome',
                                'categoria_ativa',
                            ), $this->input->POST()
                    );
                    $data['categoria_meta_link'] = url_amigavel($data['categoria_nome']);

                    $data = html_escape($data);
                    $this->Core_model->ATUALIZAR('categorias', $data, array('categoria_id' => $categoria_id));
                    redirect('intranet/categorias');
                } else {
                    // Se der errado volta para página de formulário com msg de erro.
                    $data = array(
                        'titulo' => 'Editar Categorias',
                        'subtitulo' => 'Editar Categoria no banco de dados.',
                        'icone_view' => 'fa fa-list',
                        'categoria' => $objeto_categoria_id,
                    );

                    $this->load->view('intranet/layout/header', $data);
                    $this->load->view('intranet/layout/_navbar');
                    $this->load->view('intranet/layout/_sidebar');
                    $this->load->view('intranet/categorias/core');
                    $this->load->view('intranet/layout/footer');
                }
            }
        }
    }

    public function Check_Categoria_Nome($categoria_nome) {
        $categoria_id = $this->input->POST('categoria_id');

        if ($this->Core_model->get_by_id('categorias',
                        array(
                            'categoria_nome' => $categoria_nome,
                            'categoria_id !=' => $categoria_id,
                ))) {
            $this->form_validation->set_message('Check_Categoria_Nome', 'Esta categoria já existe no bando de dados!');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function Del($categoria_id = NULL) {
        $categoria_id = (int) $categoria_id; // type cast = força a variavel ser inteiro.
        // Instrução para verificar se existe bug no banco e categoria existe, caso não, não irá deletar.
        if (!$categoria_id || !$this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id))) {
            $this->session->set_flashdata('error', 'Categoria não encontrada!');
            redirect('intranet/categorias');
        }
        // Instrução para verificar se está ativa, caso sim, não irá deletar.
        if ($this->Core_model->get_by_id('categorias', array('categoria_id' => $categoria_id, 'categoria_ativa' => 1))) {
            $this->session->set_flashdata('error', 'Não é possivel EXCLUIR uma categoria que esta ativa!');
            redirect('intranet/categorias');
        }
        // Instrução de exclusão da linha no banco.
        $this->Core_model->DELETAR('categorias', array('categoria_id' => $categoria_id));
        redirect('intranet/categorias');
    }

}
