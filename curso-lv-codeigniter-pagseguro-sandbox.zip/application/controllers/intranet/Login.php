<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Login extends CI_Controller {

    public function index() {
        $data = array(
            'titulo' => 'Login Dashboard Ecommerce CI PagSeguro Sandbox',
        );
        $this->load->view('login/index', $data);
    }

    public function Auth() {
//        echo '<pre>';
//        print_r($this->input->POST());
//        exit();
        
        $identity = html_escape($this->input->POST('email'));
        $password = html_escape($this->input->POST('password'));
        $remember = ($this->input->POST('remember' ? TRUE : FALSE)); // remember the user

        if ($this->ion_auth->login($identity, $password, $remember)) {
            $usuario = $this->Core_model->get_by_id('users', array('email' => $identity));

            $this->session->set_flashdata('sucesso', 'Seja bem vindo(a) ' . $usuario->first_name);
            redirect('intranet/');
        } else {
            $this->session->set_flashdata('error', 'Erro de acesso! Verifique seu e-mail ou senha.');
            redirect('intranet/login/');
        }
    }

    public function Logout() {
        $this->ion_auth->logout();
        redirect('intranet/login/');
    }

}
