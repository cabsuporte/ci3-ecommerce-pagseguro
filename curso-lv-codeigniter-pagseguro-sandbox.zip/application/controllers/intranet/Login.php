<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Login extends CI_Controller {

    public function index() {
        $data = array(
            'titulo' => 'Login do sistema',
        );
        $this->load->view('login/index', $data);
    }

    public function Auth() {
        $identity = html_escape($this->input->POST('email'));
        $password = html_escape($this->input->POST('password'));
        $remember = ($this->input->POST('remember' ? TRUE : FALSE)); // remember the user

        if ($this->ion_auth->login($identity, $password, $remember)) {
            $usuario = $this->Core_model->get_by_id('users', array('email' => $identity));

            $this->session->set_flashdata('sucesso', 'Seja bem vindo(a) ' . $usuario->first_name);
            redirect('/');
        } else {
            $this->session->set_flashdata('error', 'Erro de acesso! Verifique seu e-mail ou senha.');
            redirect($this->router->fetch_class());
        }
    }

    public function Logout() {
        $this->ion_auth->logout();
        redirect($this->router->fetch_class());
    }

}
