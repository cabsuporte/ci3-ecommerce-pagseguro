<?php

defined('BASEPATH') or exit('Ação não permitida');

function info_header_footer() {
    // Enviando informações do sistema para Header e o Footer
    $CI = & get_instance(); // Na classe Helper o $CI funciona como a chamada $this utilizado em controllers, models e views
    $sistema = $CI->Core_model->get_by_id('sistema', array('sistema_id' => 1));
    return $sistema;
}

function grandes_marcas_navbar() { // grandes marcas para o navbar
    $CI = & get_instance(); // Força a variavel para utilizar o metodo em qualquer parte do site, sem precisar do Controller.
    $grandes_marcas = $CI->Loja_model->get_grandes_marcas();
    return $grandes_marcas;
}

function get_categorias_navbar() { // Categorias para o navbar
    $CI = & get_instance(); // Força a variavel para utilizar o metodo em qualquer parte do site, sem precisar do Controller.
    $categorias_navbar = $CI->Loja_model->get_categorias();
    return $categorias_navbar;
}

function get_subcategorias_navbar($categoria_id = NULL) { // Subcategorias para o navbar
    $CI = & get_instance(); // Força a variavel para utilizar o metodo em qualquer parte do site, sem precisar do Controller.
    $subcategorias_navbar = $CI->Loja_model->get_subcategorias($categoria_id);
    return $subcategorias_navbar;
}

function url_amigavel($string = NULL) {
    $string = remove_acentos($string);
    return url_title($string, '-', TRUE);
}

function remove_acentos($string = NULL) {
    $procurar = array('À', 'Á', 'Ã', 'Â', 'É', 'Ê', 'Í', 'Ó', 'Õ', 'Ô', 'Ú', 'Ü', 'Ç', 'à', 'á', 'ã', 'â', 'é', 'ê', 'í', 'ó', 'õ', 'ô', 'ú', 'ü', 'ç');
    $substituir = array('a', 'a', 'a', 'a', 'e', 'r', 'i', 'o', 'o', 'o', 'u', 'u', 'c', 'a', 'a', 'a', 'a', 'e', 'e', 'i', 'o', 'o', 'o', 'u', 'u', 'c');
    return str_replace($procurar, $substituir, $string);
}

function formata_data_banco_com_hora($string) {

    $dia_sem = date('w', strtotime($string));

    if ($dia_sem == 0) {
        $semana = "Domingo";
    } elseif ($dia_sem == 1) {
        $semana = "Segunda-feira";
    } elseif ($dia_sem == 2) {
        $semana = "Terça-feira";
    } elseif ($dia_sem == 3) {
        $semana = "Quarta-feira";
    } elseif ($dia_sem == 4) {
        $semana = "Quinta-feira";
    } elseif ($dia_sem == 5) {
        $semana = "Sexta-feira";
    } else {
        $semana = "Sábado";
    }

    $dia = date('d', strtotime($string));

    $mes_num = date('m', strtotime($string));

    $ano = date('Y', strtotime($string));
    $hora = date('H:i', strtotime($string));

    return $dia . '/' . $mes_num . '/' . $ano . ' ' . $hora;
}

function formata_data_banco_sem_hora($string) {

    $dia_sem = date('w', strtotime($string));

    if ($dia_sem == 0) {
        $semana = "Domingo";
    } elseif ($dia_sem == 1) {
        $semana = "Segunda-feira";
    } elseif ($dia_sem == 2) {
        $semana = "Terça-feira";
    } elseif ($dia_sem == 3) {
        $semana = "Quarta-feira";
    } elseif ($dia_sem == 4) {
        $semana = "Quinta-feira";
    } elseif ($dia_sem == 5) {
        $semana = "Sexta-feira";
    } else {
        $semana = "Sábado";
    }

    $dia = date('d', strtotime($string));

    $mes_num = date('m', strtotime($string));

    $ano = date('Y', strtotime($string));
    $hora = date('H:i', strtotime($string));

    return $dia . '/' . $mes_num . '/' . $ano;
}

function dataDiaDb() {
    //date_default_timezone_get('America/Sao_paulo');
    $formato = 'DATE_W3C';
    $hora = time();
    return standard_date($formato, $hora);
}

function dataDb() {
    date_default_timezone_get('America/Sao_paulo');
    $stringdedata = '%Y-%m-%d';
    $data = time();
    $data = mdate($stringdedata, $data);
    return $data;
}

function formataDataDb($data = NULL) {
    if ($data) {
        //ENTRADA -> 10/05/1980
        $data = explode("/", $data);

        //SAÍDA -> 1980-05-10
        return $data[2] . '-' . $data[1] . '-' . $data[0];
    }
}

function formataDataView($data = NULL) {
    if ($data) {
        //ENTRADA -> 1980-05-10
        $data = explode("-", $data);

        //SAÍDA -> 10/05/1980
        return $data[2] . '/' . $data[1] . '/' . $data[0];
    }
}

function formataMoeadoReal($valor = NULL, $real = FALSE) {
    if ($valor) {
        $valor = ($real == TRUE ? 'R$' : '') . number_format($valor, 2, ',', '.');
        return $valor;
    }
}
