<!DOCTYPE html>
<html lang="pt-BR">
    <!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->
    <head>
        <meta charset="UTF-8">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
        <title><?= (isset($titulo) ? $titulo : 'Login sistema'); ?> | ECOCIPS</title>
        <!-- General CSS Files -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/app.min.css">
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/bundles/bootstrap-social/bootstrap-social.css">
        <!-- Template CSS -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/style.css">
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/components.css">
        <!-- Custom style CSS -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/custom.css">
        <link rel='shortcut icon' type='image/x-icon' href='<?= base_url('backend'); ?>assets/img/favicon.ico' />
    </head>

    <body>
        <div class="loader"></div>

        <div id="app">
            <section class="section">
                <div class="container mt-5">
                    <div class="row">

                        <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                            <div class="card card-primary">
                                <div class="card-header">
                                    <h4>Login</h4>
                                </div>

                                <!-- Bloco mensagem Flashdata - Error -->
                                <?php if ($message = $this->session->flashdata('error')): ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                <i class="fas fa-check-circle"></i>
                                                <strong><?= $message; ?></strong>
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <!--// Bloco mensagem Flashdata - Error -->

                                <div class="card-body">
                                    <?php $atributos = "needs-validation"; ?>
                                    <?= form_open('intranet/login/auth', $atributos); ?>
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input id="email" type="email" class="form-control" name="email" tabindex="1" required autofocus>
                                        <div class="invalid-feedback">
                                            Por favor preencha seu email
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="d-block">
                                            <label for="password" class="control-label">Password</label>
                                            <div class="float-right">
                                                <a href="<?= base_url('auth/forgot_password'); ?>" class="text-small">
                                                    Esqueceu sua senha?
                                                </a>
                                            </div>
                                        </div>
                                        <input id="password" type="password" class="form-control" name="password" tabindex="2" required>
                                        <div class="invalid-feedback">
                                            Por favor preencha sua senha
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" name="remember" class="custom-control-input" tabindex="3" id="remember-me">
                                            <label class="custom-control-label" for="remember-me">Lembre de mim</label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                                            Entrar
                                        </button>
                                    </div>
                                    <?= form_close(); ?>
                                    <div class="text-center mt-4 mb-3">
                                        <div class="text-job text-muted">Faça login com redes sociais</div>
                                    </div>
                                    <div class="row sm-gutters">
                                        <div class="col-6">
                                            <a class="btn btn-block btn-social btn-facebook">
                                                <span class="fab fa-facebook"></span> Facebook
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a class="btn btn-block btn-social btn-twitter">
                                                <span class="fab fa-twitter"></span> Twitter
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-5 text-muted text-center">
                                Não tem conta?<a href="<?= base_url('intranet/login'); ?>"> Crie uma agora.</a>
                            </div>
                            <?php if ($this->router->fetch_class() != 'Login') { ?>
                                <div class="mt-5 text-muted text-center">
                                    Desenvolvimento Agencia Cew [Bruno Luis]
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- General JS Scripts -->
        <script src="<?= base_url('backend/'); ?>assets/js/app.min.js"></script>
        <!-- JS Libraies -->
        <!-- Page Specific JS File -->
        <!-- Template JS File -->
        <script src="<?= base_url('backend/'); ?>assets/js/scripts.js"></script>
        <!-- Custom JS File -->
        <script src="<?= base_url('backend/'); ?>assets/js/custom.js"></script>
    </body>


    <!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->
</html>