<footer class="main-footer">
    <div class="footer-left">
        <a href="https://cabti.com.br">CABTI | Bruno Luis</a></a>
    </div>
    <div class="footer-right">
    </div>
</footer>
</div>
</div>
<!-- General JS Scripts -->
<script src="<?= base_url('backend/'); ?>assets/js/app.min.js"></script>
<!-- JS Libraies -->
<script src="<?= base_url('backend/'); ?>assets/bundles/apexcharts/apexcharts.min.js"></script>
<!-- Page Specific JS File -->
<script src="<?= base_url('backend/'); ?>assets/js/page/index.js"></script>
<!--<script src="<?= base_url('backend/'); ?>assets/js/util.js"></script>-->

<?php if (isset($scripts)): ?>
    <?php foreach ($scripts as $script): ?>
        <script src="<?= base_url('backend/' . $script); ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>
        
<!-- Template JS File -->
<script src="<?= base_url('backend/'); ?>assets/js/scripts.js"></script>
<!-- Custom JS File -->
<script src="<?= base_url('backend/'); ?>assets/js/custom.js"></script>

</body>
<!-- index.html  21 Nov 2019 03:47:04 GMT -->
</html>