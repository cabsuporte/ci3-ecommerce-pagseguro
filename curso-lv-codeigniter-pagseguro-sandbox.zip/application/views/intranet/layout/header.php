<!DOCTYPE html>
<html lang="pt-BR">

    <!-- index.html  21 Nov 2019 03:44:50 GMT -->
    <head>
        <meta charset="UTF-8">
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
        <title><?= (isset($titulo) ? $titulo : 'Criando Loja Virtual com CodeIgniter 3 com PagSeguro Sandbox'); ?> | CLVCPS</title>
        <!-- General CSS Files -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/app.min.css">
        <!-- Template CSS -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/style.css">
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/components.css">
        <?php if (isset($styles)): ?>
            <?php foreach ($styles as $style): ?>
                <link href="<?= base_url('backend/' . $style); ?>" rel="stylesheet">
            <?php endforeach; ?>
        <?php endif; ?>
        <!-- Custom style CSS -->
        <link rel="stylesheet" href="<?= base_url('backend/'); ?>assets/css/custom.css">
        <link rel='shortcut icon' type='image/x-icon' href='<?= base_url('backend/'); ?>assets/img/favicon.ico' />

        <script>
            var BASE_URL = "<?= base_url(); ?>";
        </script>

    </head>

    <body>
        <div class="loader"></div>
        <div id="app">
            <div class="main-wrapper main-wrapper-1">
                <div class="navbar-bg"></div>