<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?= base_url('intranet/home'); ?>"> <img alt="image" src="<?= base_url('backend/assets/img/logo.png'); ?>" class="header-logo" /> <span
                    class="logo-name">Otika</span>
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown active" <?= $this->router->fetch_class() == 'home' && $this->router->fetch_method() == 'index' ? 'active' : ''; ?>">
                <a href="<?= base_url('intranet/'); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard E-commerce</span></a>
            </li>
            
            <li class="dropdown" <?= $this->router->fetch_class() == 'marcas' && $this->router->fetch_method() == 'index' ? 'active' : ''; ?>">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i
                        data-feather="briefcase"></i><span>Marcas</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="<?= base_url('intranet/marcas/'); ?>">Lista</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/marcas/Core'); ?>">Adicionar</a></li>
                </ul>
            </li>
            <li class="dropdown" <?= $this->router->fetch_class() == 'categorias' && $this->router->fetch_method() == 'index' ? 'active' : ''; ?>">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Categorias</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="<?= base_url('intranet/categorias/'); ?>">Lista de categorias</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/categorias/Core'); ?>">Adicionar categorias</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/subcategorias/'); ?>">Lista subcategorias</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/subcategorias/Core'); ?>">Adicionar suncategorias</a></li>
                </ul>
            </li>
            <li class="dropdown" <?= $this->router->fetch_class() == 'produtos' && $this->router->fetch_method() == 'index' ? 'active' : ''; ?>">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="mail"></i><span>Produtos</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="<?= base_url('intranet/produtos/'); ?>">Lista</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/produtos/Core'); ?>">Adicionar</a></li>
                </ul>
            </li>
            <li class="menu-header">Sistema</li>
            <li class="dropdown" <?= $this->router->fetch_class() == 'sistema' && $this->router->fetch_method() == 'index' ? 'active' : ''; ?>">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="copy"></i><span>Ação</span></a>
                <ul class="dropdown-menu">
                    <li><a class="nav-link" href="<?= base_url('intranet/sistema'); ?>">Sistema</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/usuarios'); ?>">Usuários</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/sistema/correios'); ?>">Correios</a></li>
                    <li><a class="nav-link" href="<?= base_url('intranet/sistema/pagseguro'); ?>">PagSeguro</a></li>
                </ul>
            </li>
        </ul>
    </aside>
</div>