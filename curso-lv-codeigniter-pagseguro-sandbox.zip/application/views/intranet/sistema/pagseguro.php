<div class="main-content">
    <section class="section">
        <div class="page-header mb-3">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="<?= $icone_view; ?> bg-blue"></i>
                        <div class="d-inline">
                            <h5><?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url(); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/sistema'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Bloco mensagem Flashdata - Sucesso -->
        <?php if ($message = $this->session->flashdata('sucesso')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <h4><i class="fa fa-check-square">&nbsp;</i><?= $message; ?></h4>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="fa fa-x"></i></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Sucesso -->       
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($pagseguro)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-primary"><h6><i class="ik ik-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($pagseguro) ? '<i class="fa fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($pagseguro->config_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-primary"><i class="ik ik-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_index" method="POST">
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="config_email">E-mail de acesso</label>
                                    <input type="text" class="form-control" name="config_email"
                                           value="<?= (isset($pagseguro->config_email) ? $pagseguro->config_email : set_value('config_email')); ?>">
                                           <?= form_error('config_email', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="config_token">Token de acesso</label>
                                    <input type="text" class="form-control" name="config_token" 
                                           value="<?= (isset($pagseguro->config_token) ? $pagseguro->config_token : set_value('config_token')); ?>">
                                           <?= form_error('config_token', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="config_ambiente">Ambiente de acesso</label>
                                    <select class="form-control" name="config_ambiente">
                                        <?php if (isset($pagseguro)) { ?>
                                            <option value="0" <?= ($pagseguro->config_ambiente == 0 ? 'selected' : ''); ?> >Produção</option>
                                            <option value="1" <?= ($pagseguro->config_ambiente == 1 ? 'selected' : ''); ?> >Sandbox (Teste)</option>
                                        <?php } else { ?>
                                            <option value="0">Produção</option>
                                            <option value="1">Sandbox (Teste)</option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>

                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a href="<?= base_url('intranet/sistema/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>