<div class="main-content">
    <section class="section">
        <div class="page-header mb-3">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="<?= $icone_view; ?> bg-blue"></i>
                        <div class="d-inline">
                            <h5><?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url(); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/sistema'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Bloco mensagem Flashdata - Sucesso -->
        <?php if ($message = $this->session->flashdata('sucesso')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <h4><i class="fa fa-check-square">&nbsp;</i><?= $message; ?></h4>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="fa fa-x"></i></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Sucesso -->       
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($correio)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-primary"><h6><i class="ik ik-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($correio) ? '<i class="fa fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($correio->config_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-primary"><i class="ik ik-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_index" method="POST">
                            <div class="form-group row">
                                <div class="col-md-2">
                                    <label for="config_cep_origem">CEP de Origem</label>
                                    <input type="text" class="form-control cep" name="config_cep_origem" 
                                           value="<?= (isset($correio->config_cep_origem) ? $correio->config_cep_origem : set_value('config_cep_origem')); ?>">
                                           <?= form_error('config_cep_origem', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="config_codigo_pac">Cod PAC</label>
                                    <input type="text" class="form-control codigo_servico_correios" name="config_codigo_pac"
                                           value="<?= (isset($correio->config_codigo_pac) ? $correio->config_codigo_pac : set_value('config_codigo_pac')); ?>">
                                           <?= form_error('config_codigo_pac', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="config_codigo_sedex">Cod SEDEX</label>
                                    <input type="text" class="form-control codigo_servico_correios" name="config_codigo_sedex" 
                                           value="<?= (isset($correio->config_codigo_sedex) ? $correio->config_codigo_sedex : set_value('config_codigo_sedex')); ?>">
                                           <?= form_error('config_codigo_sedex', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="config_somar_frete">Somar Frete</label>
                                    <input type="text" class="form-control money2" name="config_somar_frete" 
                                           value="<?= (isset($correio->config_somar_frete) ? $correio->config_somar_frete : set_value('config_somar_frete')); ?>">
                                           <?= form_error('config_somar_frete', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="config_valor_declarado">Valor Declarado</label>
                                    <input type="text" class="form-control money2" name="config_valor_declarado" 
                                           value="<?= (isset($correio->config_valor_declarado) ? $correio->config_valor_declarado : set_value('config_valor_declarado')); ?>">
                                           <?= form_error('config_valor_declarado', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>

                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a href="<?= base_url('intranet/sistema/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>