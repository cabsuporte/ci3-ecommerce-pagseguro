<div class="main-content">
    <section class="section">
        <div class="page-header mb-3">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <i class="<?= $icone_view; ?> bg-blue"></i>
                        <div class="d-inline">
                            <h5><?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url(); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/sistema'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Bloco mensagem Flashdata - Sucesso -->
        <?php if ($message = $this->session->flashdata('sucesso')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <h4><i class="fa fa-check-square">&nbsp;</i><?= $message; ?></h4>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><i class="fa fa-x"></i></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Sucesso -->       
        <div class="row">

            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($sistema)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-secondary"><h6><i class="ik ik-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($sistema) ? '<i class="fa fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($sistema->sistema_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-secondary"><i class="ik ik-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_index" method="POST">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="sistema_razao_social">Razão social</label>
                                    <input type="text" class="form-control" name="sistema_razao_social" 
                                           value="<?= (isset($sistema->sistema_razao_social) ? $sistema->sistema_razao_social : set_value('sistema_razao_social')); ?>">
                                           <?= form_error('sistema_razao_social', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="sistema_nome_fantasia">Nome fantasia</label>
                                    <input type="text" class="form-control" name="sistema_nome_fantasia" 
                                           value="<?= (isset($sistema->sistema_nome_fantasia) ? $sistema->sistema_nome_fantasia : set_value('sistema_nome_fantasia')); ?>">
                                           <?= form_error('sistema_nome_fantasia', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-3">
                                    <label for="sistema_cnpj">CNPJ</label>
                                    <input type="text" class="form-control cnpj" name="sistema_cnpj" 
                                           value="<?= (isset($sistema->sistema_cnpj) ? $sistema->sistema_cnpj : set_value('sistema_cnpj')); ?>">
                                           <?= form_error('sistema_cnpj', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="sistema_ie">IE</label>
                                    <input type="text" class="form-control" name="sistema_ie" 
                                           value="<?= (isset($sistema->sistema_ie) ? $sistema->sistema_ie : set_value('sistema_ie')); ?>">
                                           <?= form_error('sistema_ie', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="sistema_telefone_fixo">Telefone fixo</label>
                                    <input type="sistema_telefone_fixo" class="form-control phone_with_ddd" name="sistema_telefone_fixo" 
                                           value="<?= (isset($sistema->sistema_telefone_fixo) ? $sistema->sistema_telefone_fixo : set_value('sistema_telefone_fixo')); ?>">
                                           <?= form_error('sistema_telefone_fixo', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="sistema_telefone_movel">Celular</label>
                                    <input type="sistema_telefone_movel" class="form-control sp_celphones" name="sistema_telefone_movel"
                                           value="<?= (isset($sistema->sistema_ie) ? $sistema->sistema_ie : set_value('sistema_telefone_movel')); ?>">
                                           <?= form_error('sistema_telefone_movel', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">

                            </div>
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="sistema_email">E-mail</label>
                                    <input type="sistema_email" class="form-control" name="sistema_email" 
                                           value="<?= (isset($sistema->sistema_email) ? $sistema->sistema_email : set_value('sistema_email')); ?>">
                                           <?= form_error('sistema_email', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="sistema_site_url">Site URL</label>
                                    <input type="sistema_site_url" class="form-control" name="sistema_site_url"
                                           value="<?= (isset($sistema->sistema_site_url) ? $sistema->sistema_site_url : set_value('sistema_site_url')); ?>">
                                           <?= form_error('sistema_site_url', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="sistema_endereco">Endereço</label>
                                    <input type="sistema_endereco" class="form-control" name="sistema_endereco"
                                           value="<?= (isset($sistema->sistema_endereco) ? $sistema->sistema_endereco : set_value('sistema_endereco')); ?>">
                                           <?= form_error('sistema_endereco', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-2">
                                    <label for="sistema_numero">Nº</label>
                                    <input type="sistema_numero" class="form-control" name="sistema_numero" 
                                           value="<?= (isset($sistema->sistema_numero) ? $sistema->sistema_numero : set_value('sistema_numero')); ?>">
                                           <?= form_error('sistema_numero', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="sistema_cep">CEP</label>
                                    <input type="sistema_cep" class="form-control cep" name="sistema_cep" 
                                           value="<?= (isset($sistema->sistema_cep) ? $sistema->sistema_cep : set_value('sistema_cep')); ?>">
                                           <?= form_error('sistema_cep', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="sistema_cidade">Cidade</label>
                                    <input type="sistema_cidade" class="form-control" name="sistema_cidade"
                                           value="<?= (isset($sistema->sistema_cidade) ? $sistema->sistema_cidade : set_value('sistema_cidade')); ?>">
                                           <?= form_error('sistema_cidade', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="sistema_estado">Estado</label>
                                    <input type="sistema_estado" class="form-control uf" name="sistema_estado" 
                                           value="<?= (isset($sistema->sistema_estado) ? $sistema->sistema_estado : set_value('sistema_estado')); ?>">
                                           <?= form_error('sistema_estado', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="sistema_produtos_destaques">Produtos em destaques</label>
                                    <input type="number" class="form-control" name="sistema_produtos_destaques" 
                                           value="<?= (isset($sistema->sistema_produtos_destaques) ? $sistema->sistema_produtos_destaques : set_value('sistema_produtos_destaques')); ?>">
                                           <?= form_error('sistema_produtos_destaques', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a href="<?= base_url('intranet/sistema/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>