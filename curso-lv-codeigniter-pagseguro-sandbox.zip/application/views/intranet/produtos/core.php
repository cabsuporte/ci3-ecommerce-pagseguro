<div class="main-content">
    <section class="section">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-6 mb-2">
                    <div class="page-header-title">
                        <div class="d-inline">
                            <h5><i class="<?= $icone_view; ?>"></i>&nbsp;<?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="breadcrumb-container pull-right" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/produtos'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($produto)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-secundary"><h6><i class="fa fa-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($produto) ? '<i class="fa fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($produto->produto_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-secundary"><h6 class="text-secundary"><i class="fa fa-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6></div>
                                    <div class="col-lg-6 text-secundary text-right">
                                        <a href="<?= base_url('intranet/categorias/core/'); ?>" 
                                           data-toggle="tooltip" 
                                           data-placement="right" 
                                           title="Adicionar nova Categoria" 
                                           class="btn btn-success"><i class="fa fa-plus-circle"></i> Categorias</a>
                                        <a href="<?= base_url('intranet/subcategorias/core/'); ?>" 
                                           data-toggle="tooltip" 
                                           data-placement="right" 
                                           title="Adicionar nova Subcategoria" 
                                           class="btn btn-success"><i class="fa fa-plus-circle"></i> Subcategorias</a>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_core" method="POST">
                            <?php if (isset($produto)): ?>
                                <div class="form-row">
                                    <div class="col-md-12">
                                        <label>Meta Link do Produto</label>
                                        <p class="text-info"><?= $produto->produto_meta_link; ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="form-group row">
                                <div class="col-md-3">
                                    <label for="produto_codigo">Código do Produto</label>
                                    <input type="text" name="produto_codigo" class="form-control border-0" 
                                           value="<?= (isset($produto) ? $produto->produto_codigo : $codigo_gerado); ?>" readonly="">
                                </div>
                                <div class="col-md-3">
                                    <label for="produto_nome">Produto nome</label>
                                    <input type="text" class="form-control" name="produto_nome" 
                                           value="<?= (isset($produto->produto_nome) ? $produto->produto_nome : set_value('produto_nome')); ?>">
                                           <?= form_error('produto_nome', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="produto_categoria_id">Categoria</label>
                                    <select class="form-control" name="produto_categoria_id" required="">
                                        <option value="">Escolha um...</option>
                                        <?php foreach ($categorias as $categoria) { ?>
                                            <?php if (isset($produto)) { ?>
                                                <option value="<?= $categoria->categoria_id; ?>" <?= ($categoria->categoria_id == $produto->produto_categoria_id ? 'selected' : ''); ?> ><?= $categoria->categoria_nome; ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $categoria->categoria_id; ?>"><?= $categoria->categoria_nome; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_marca_id', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="produto_subcategoria_id">Subcategoria</label>
                                    <select class="form-control" name="produto_subcategoria_id" required="">
                                        <option value="">Escolha um...</option>
                                        <?php foreach ($subcategorias as $subcategoria) { ?>
                                            <?php if (isset($produto)) { ?>
                                                <option value="<?= $subcategoria->subcategoria_id; ?>" <?= ($subcategoria->subcategoria_id == $produto->produto_subcategoria_id ? 'selected' : ''); ?> ><?= $subcategoria->subcategoria_nome; ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $subcategoria->subcategoria_id; ?>"><?= $subcategoria->subcategoria_nome; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_subcategoria_id', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-2">
                                    <label for="produto_marca_id">Marca</label>
                                    <select class="form-control" name="produto_marca_id" required="">
                                        <option value="">Escolha um...</option>
                                        <?php foreach ($marcas as $marca) { ?>
                                            <?php if (isset($produto)) { ?>
                                                <option value="<?= $marca->marca_id; ?>" <?= ($marca->marca_id == $produto->produto_marca_id ? 'selected' : ''); ?> ><?= $marca->marca_nome; ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $marca->marca_id; ?>"><?= $marca->marca_nome; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_marca_id', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_download">Mídia download</label>
                                    <select class="form-control" name="produto_download">
                                        <?php if (isset($produto)) { ?>
                                            <option value="0" <?= ($produto->produto_download == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($produto->produto_download == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_controlar_estoque', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_peso">Peso</label>
                                    <input type="text" class="form-control" name="produto_peso" 
                                           value="<?= (isset($produto->produto_peso) ? $produto->produto_peso : set_value('produto_peso')); ?>">
                                           <?= form_error('produto_peso', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_altura">Altura</label>
                                    <input type="text" class="form-control" name="produto_altura" 
                                           value="<?= (isset($produto->produto_altura) ? $produto->produto_altura : set_value('produto_altura')); ?>">
                                           <?= form_error('produto_altura', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_largura">Largura</label>
                                    <input type="text" class="form-control" name="produto_largura" 
                                           value="<?= (isset($produto->produto_largura) ? $produto->produto_largura : set_value('produto_largura')); ?>">
                                           <?= form_error('produto_largura', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_comprimento">Comprimento</label>
                                    <input type="text" class="form-control" name="produto_comprimento" 
                                           value="<?= (isset($produto->produto_comprimento) ? $produto->produto_comprimento : set_value('produto_comprimento')); ?>">
                                           <?= form_error('produto_comprimento', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-3">
                                    <label for="produto_quantidade_estoque">Quantidade</label>
                                    <input type="text" class="form-control" name="produto_quantidade_estoque" 
                                           value="<?= (isset($produto->produto_quantidade_estoque) ? $produto->produto_quantidade_estoque : set_value('produto_quantidade_estoque')); ?>">
                                           <?= form_error('produto_quantidade_estoque', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_destaque">Destaque</label>
                                    <select class="form-control" name="produto_destaque">
                                        <?php if (isset($produto)) { ?>
                                            <option value="0" <?= ($produto->produto_destaque == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($produto->produto_destaque == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_destaque', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="produto_controlar_estoque">Estoque</label>
                                    <select class="form-control" name="produto_controlar_estoque">
                                        <?php if (isset($produto)) { ?>
                                            <option value="0" <?= ($produto->produto_controlar_estoque == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($produto->produto_controlar_estoque == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                    <?= form_error('produto_controlar_estoque', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_ativo">Ativo</label>
                                    <select class="form-control" name="produto_ativo">
                                        <?php if (isset($produto)) { ?>
                                            <option value="0" <?= ($produto->produto_ativo == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($produto->produto_ativo == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label for="produto_valor">Valor</label>
                                    <input type="text" class="form-control money2" name="produto_valor" 
                                           value="<?= (isset($produto->produto_valor) ? $produto->produto_valor : set_value('produto_valor')); ?>">
                                           <?= form_error('produto_valor', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-12">
                                    <label for="produto_descricao">Descrição do produto</label>
                                    <textarea name="produto_descricao" class="form-control" required=""><?= (isset($produto->produto_descricao) ? $produto->produto_descricao : set_value('produto_descricao')); ?></textarea>
                                    <?= form_error('produto_descricao', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            
                            <!-- Parte do pload da imagem -->
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label>Imagens do produto</label>
                                    <div id="fileuploader"></div>
                                    <div id="erro_uploaded" class="text-danger"></div>
                                    <?= form_error('fotos_produtos', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-8">
                                    <?php if (isset($produto)) { ?>
                                        <div id="uploaded_image" class="text-danger">
                                            <?php foreach ($foto_produto as $foto) { ?>
                                                <ul style="list-style: none; display: inline-block;">
                                                    <li>
                                                        <img src="<?= base_url('assets/uploads/produtos/' . $foto->foto_caminho); ?>" width="80" class="img-thumbnail mr-1 mb-2">
                                                        <input type="hidden" name="fotos_produtos[]" value="<?= $foto->foto_caminho; ?>">
                                                        <a href="javascript:(void)" class="btn btn-danger d-block btn-icon mx-auto mb-30 btn-remove"><i class="fas fa-times"></i></a>
                                                    </li>
                                                </ul>
                                            <?php } ?>
                                        </div>
                                    <?php } else { ?>
                                        <div id="uploaded_image" class="text-danger"></div>
                                    <?php } ?>
                                </div>
                            </div>
                            <!--// Parte do pload da imagem -->
                            
                            <?php if (isset($produto)) { ?>
                                <input type="hidden" name="produto_id" value="<?= $produto->produto_id; ?>"> <!-- CHAVE DE EDIÇÃO DO FORMULARIO -->
                            <?php } ?>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>

                                <a href="<?= base_url('intranet/produtos/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>