<div class="main-content">
    <section class="section">
        <div class="page-header mb-3">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <div class="d-inline">
                            <h5><i class="<?= $icone_view; ?>"></i>&nbsp;<?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/usuarios'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($usuario)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-primary"><h6><i class="fa fa-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($usuario) ? '<i class="fas fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($usuario->ultima_atualizacao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-primary"><i class="ik ik-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_core" method="POST">
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">Nome</label>
                                    <input type="text" class="form-control" name="first_name" 
                                           value="<?= (isset($usuario->first_name) ? $usuario->first_name : set_value('first_name')); ?>">
                                           <?= form_error('first_name', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">Sobrenome</label>
                                    <input type="text" class="form-control" name="last_name" 
                                           value="<?= (isset($usuario->last_name) ? $usuario->last_name : set_value('last_name')); ?>">
                                           <?= form_error('last_name', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">Usuário</label>
                                    <input type="text" class="form-control" name="username" 
                                           value="<?= (isset($usuario->username) ? $usuario->username : set_value('username')); ?>">
                                           <?= form_error('username', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">E-mail (Login)</label>
                                    <input type="text" class="form-control" name="email" 
                                           value="<?= (isset($usuario->email) ? $usuario->email : set_value('email')); ?>">
                                           <?= form_error('email', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">Senha</label>
                                    <input type="password" class="form-control" name="password" 
                                           value="">
                                           <?= form_error('password', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-6">
                                    <label for="exampleInputUsername1">Confirmar senha</label>
                                    <input type="password" class="form-control" name="confirm_password">
                                    <?= form_error('confirm_password', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>

                            <?php if ($this->ion_auth->is_admin()): ?>
                                <div class="form-group row">
                                    <div class="col-md-6">
                                        <label for="exampleInputUsername1">Perfil de acesso</label>
                                        <select class="form-control" name="perfil">
                                            <?php if (isset($usuario)) { ?>
                                                <option value="1" <?= ($perfil_usuario->id == 1 ? 'selected' : ''); ?> >Administrador</option>
                                                <option value="2" <?= ($perfil_usuario->id == 2 ? 'selected' : ''); ?> >Atendente</option>
                                            <?php } else { ?>
                                                <option value="1">Administrador</option>
                                                <option value="2">Atendente</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="exampleInputUsername1">Ativo</label>
                                        <select class="form-control" name="active">
                                            <?php if (isset($usuario)) { ?>
                                                <option value="0" <?= ($usuario->active == 0 ? 'selected' : ''); ?> >Não</option>
                                                <option value="1" <?= ($usuario->active == 1 ? 'selected' : ''); ?> >Sim</option>
                                            <?php } else { ?>
                                                <option value="0">Não</option>
                                                <option value="1">Sim</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if (isset($usuario)) { ?>
                                <input type="hidden" name="usuario_id" value="<?= $usuario->id; ?>">
                            <?php } ?>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a href="<?= base_url('intranet/usuarios/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>