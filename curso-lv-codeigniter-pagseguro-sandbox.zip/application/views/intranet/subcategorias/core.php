<div class="main-content">
    <section class="section">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-6 mb-2">
                    <div class="page-header-title">
                        <div class="d-inline">
                            <h5><i class="<?= $icone_view; ?>"></i>&nbsp;<?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <nav class="breadcrumb-container pull-right" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fa fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/subcategorias'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($subcategoria)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-primary"><h6><i class="fa fa-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary text-right"><h6><?php echo (isset($subcategoria) ? '<i class="fa fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($subcategoria->subcategoria_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-primary"><i class="fa fa-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_core" method="POST">
                            <div class="form-group row">
                                <div class="col-md-3">
                                    <label for="subcategoria_nome">Subcategoria nome</label>
                                    <input type="text" class="form-control" name="subcategoria_nome" 
                                           value="<?= (isset($subcategoria->subcategoria_nome) ? $subcategoria->subcategoria_nome : set_value('subcategoria_nome')); ?>">
                                           <?= form_error('subcategoria_nome', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-3">
                                    <label for="categoria">categoria nome</label>
                                    <select class="form-control" name="categoria_id" required="">
                                        <option value="">Escolha um...</option>
                                        <?php foreach ($categorias as $categoria) { ?>
                                            <?php if (isset($subcategoria)) { ?>
                                                <option value="<?= $categoria->categoria_id; ?>" <?= ($categoria->categoria_id == $subcategoria->categoria_id ? 'selected' : ''); ?> ><?= $categoria->categoria_nome; ?></option>
                                            <?php } else { ?>
                                                <option value="<?= $categoria->categoria_id; ?>"><?= $categoria->categoria_nome; ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="subcategoria_ativa">Ativo</label>
                                    <select class="form-control" name="subcategoria_ativa">
                                        <?php if (isset($subcategoria)) { ?>
                                            <option value="0" <?= ($subcategoria->subcategoria_ativa == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($subcategoria->subcategoria_ativa == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="meta_link">Meta link</label>
                                    <input type="text" class="form-control" name="subcategoria_meta_link" 
                                           value="<?= (isset($subcategoria->subcategoria_meta_link) ? $subcategoria->subcategoria_meta_link : set_value('subcategoria_meta_link')); ?>" readonly="">
                                           <?= form_error('subcategoria_meta_link', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>

                            <?php if (isset($subcategoria)) { ?>
                                <input type="hidden" name="subcategoria_id" value="<?= $subcategoria->subcategoria_id; ?>">
                            <?php } ?>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a class="btn btn-secondary"
                                   aria-current="page"
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição"
                                   href="<?= base_url('intranet/subcategorias'); ?>">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>