<div class="main-content">
    <section class="section">
        <div class="page-header mb-3">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <div class="d-inline">
                            <h5><i class="<?= $icone_view; ?>"></i>&nbsp;<?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/'); ?>" title="Home"><i class="fa fa-home"></i></a>
                            </li>
                            <li class="breadcrumb-item active">
                                <a href="<?= base_url('intranet/marcas/'); ?>" title="<?= $titulo ?>"><?= $titulo ?></a>
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Bloco mensagem Flashdata - Sucesso -->
        <?php if ($message = $this->session->flashdata('sucesso')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <p><i class="fas fa-check">&nbsp;</i><?= $message; ?></p>
                        <button class="close" data-dismiss="alert"><span>&times;</span></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Sucesso -->
        <!-- Bloco mensagem Flashdata - Error -->
        <?php if ($message = $this->session->flashdata('error')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <h4><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h4>
                        <button class="close" data-dismiss="alert"><span>&times;</span></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Error -->

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-block">
                        <a href="<?= base_url('intranet/marcas/core/'); ?>" 
                           data-toggle="tooltip" 
                           data-placement="right" 
                           title="Adicionar nova forma de pagamento" 
                           class="btn btn-success"><i class="fa fa-plus-circle"></i>Novo</a>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped" id="table-1">
                            <thead>
                                <tr class="text-center">
                                    <th>#</th>
                                    <th>Marcas</th>
                                    <th>Meta link</th>
                                    <th>Criação</th>
                                    <th>Ativa</th>
                                    <th width="19%">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($marcas)) {
                                    foreach ($marcas as $marca) {
                                        ?>
                                        <tr class="text-center">
                                            <td><?= $marca->marca_id; ?></td>
                                            <td><?= $marca->marca_nome; ?></td>
                                            <td class="text-left"><i data-feather="link-2" class="text-info"></i>&nbsp;&nbsp;<?= $marca->marca_meta_link; ?></td>
                                            <td><?= formata_data_banco_com_hora($marca->marca_data_criacao); ?></td>
                                            <td>
                                                <?=
                                                ($marca->marca_ativa == 1 ? '<span class="badge badge-pill badge-success mb-1">'
                                                        . '<i class="fas fa-lock-open">&nbsp;</i>Sim</span>' : '<span class="badge badge-pill badge-danger mb-1">'
                                                        . '<i class="fas fa-lock">&nbsp;</i>Não</span>');
                                                ?>
                                            </td> <!-- Atenção nessa instrução, é bem mais fácil e consome 1 linha apenas. -->
                                            <td>
                                                <div class="table-actions text-center">
                                                    <!-- Mostrar unico usuário -->
                                                    <a href="<?= base_url("intranet/marcas/detalhes/{$marca->marca_id}"); ?>"
                                                       class="btn btn-icon btn-primary text-white"
                                                       data-toggle="tooltip" 
                                                       data-placement="bottom" 
                                                       title="Ver <?= $this->router->fetch_class(); ?>"><i class="fas fa-eye"></i></a>
                                                    <!-- Editar unico usuário -->   
                                                    <a href="<?= base_url('intranet/marcas/core/' . $marca->marca_id); ?>"
                                                       class="btn btn-icon btn-info text-white"
                                                       data-toggle="tooltip" 
                                                       data-placement="bottom" 
                                                       title="Editar <?= $this->router->fetch_class(); ?>"><i class="fas fa-edit"></i></a>&nbsp;
                                                    <!-- Excluir unico unico -->   
                                                    <button type="button" 
                                                            class="btn btn-icon btn-danger text-white" 
                                                            title="Excluir <?= $this->router->fetch_class(); ?>" 
                                                            data-toggle="modal" 
                                                            data-target="#excluir-<?= $marca->marca_id; ?>"><i class="fas fa-trash"></i></button>
                                                </div>
                                            </td>
                                        </tr>

                                        <!-- Modal Excluir Dados -->
                                    <div id="excluir-<?= $marca->marca_id; ?>" class="modal fade" id="basicModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title text-danger" id="exampleModalCenterLabel">
                                                        <i class="fas fa-exclamation-triangle text-danger"></i>&nbsp; 
                                                        Tem certeza da exclusão da marca abaixo?
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="text-uppercase">Marca: <b><?= $marca->marca_nome; ?></b></p>
                                                    <p>Se deseja realmente excluir o registro, clique em <strong class="text-uppercase">Sim, excluir!</strong></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" 
                                                            data-toggle="tooltip" 
                                                            data-placement="bottom"
                                                            title="Cancelar exclusão"
                                                            class="btn btn-secondary" 
                                                            data-dismiss="modal">Não, voltar</button>
                                                    <a href="<?= base_url('intranet/marcas/Del/' . $marca->marca_id); ?>" 
                                                       class="btn btn-danger"
                                                       data-toggle="tooltip" 
                                                       data-placement="bottom" 
                                                       title="Excluir <?= $this->router->fetch_class(); ?>">Sim, excluir!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--// Modal Excluir Dados -->
                                    <?php
                                }
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>