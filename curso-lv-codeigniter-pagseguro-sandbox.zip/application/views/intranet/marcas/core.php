<div class="main-content">
    <section class="section">
        <div class="page-header">
            <div class="row align-items-end">
                <div class="col-lg-8">
                    <div class="page-header-title">
                        <div class="d-inline">
                            <h5><i class="<?= $icone_view; ?>"></i>&nbsp;<?= $titulo; ?></h5>
                            <span><?= $subtitulo; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom"
                                   title="Home">
                                    <i class="fas fa-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="<?= base_url('intranet/marcas/'); ?>" 
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Listar <?= $this->router->fetch_class(); ?>">
                                    Listar <?= $this->router->fetch_class(); ?>
                                </a>
                            </li>
                            <li class="breadcrumb-item active" 
                                aria-current="page" 
                                data-toggle="tooltip" 
                                data-placement="bottom" 
                                title="<?= $titulo; ?>"><?= $titulo ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Bloco mensagem Flashdata - Error -->
        <?php if ($message = $this->session->flashdata('error')) { ?>
            <div class="row mt-3 mb-1">
                <div class="col-lg-12">
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <h4><i class="fas fa-exclamation-triangle">&nbsp;</i><?= $message; ?></h4>
                        <button class="close" data-dismiss="alert"><span>&times;</span></button>
                    </div>
                </div>
            </div>
        <?php } ?>
        <!--// Bloco mensagem Flashdata - Error -->

        <div class="row mt-3">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <div class="container">
                            <?php if (isset($marca)) { ?>
                                <div class="row">
                                    <div class="col-lg-6 text-primary"><h6><i class="fas fa-edit">&nbsp;</i>Em processo de atualização de dados...</h6></div>
                                    <div class="col-lg-6 text-secondary"><h6><?php echo (isset($marca) ? '<i class="fas fa-calendar"></i>&nbsp;Última alteração: ' . formata_data_banco_com_hora($marca->marca_data_alteracao) : ''); ?></h6></div>
                                </div>
                            <?php } else { ?>
                                <h6 class="text-primary"><i class="ik ik-plus-circle">&nbsp;</i>Em processo de inclusão de dados...</h6>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <form class="forms-sample" name="form_core" method="POST">
                            <div class="form-group row">
                                <div class="col-md-4">
                                    <label for="marca_nome">Marca</label>
                                    <input type="text" class="form-control" name="marca_nome" 
                                           value="<?= (isset($marca->marca_nome) ? $marca->marca_nome : set_value('marca_nome')); ?>">
                                           <?= form_error('marca_nome', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="marca_ativa">Ativo</label>
                                    <select class="form-control" name="marca_ativa">
                                        <?php if (isset($marca)) { ?>
                                            <option value="0" <?= ($marca->marca_ativa == 0 ? 'selected' : ''); ?> >Não</option>
                                            <option value="1" <?= ($marca->marca_ativa == 1 ? 'selected' : ''); ?> >Sim</option>
                                        <?php } else { ?>
                                            <option value="0">Não</option>
                                            <option value="1">Sim</option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="marca_meta_link">Meta-link</label>
                                    <input type="text" class="form-control" name="marca_meta_link" 
                                           value="<?= (isset($marca->marca_meta_link) ? $marca->marca_meta_link : set_value('marca_meta_link')); ?>" readonly="">
                                           <?= form_error('marca_meta_link', '<div class="text-danger text-bold mt-1">', '</div>'); ?>
                                </div>
                            </div>

                            <?php if (isset($marca)) { ?>
                                <input type="hidden" name="marca_id" value="<?= $marca->marca_id; ?>">
                            <?php } ?>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-2"
                                        aria-current="page" 
                                        data-toggle="tooltip" 
                                        data-placement="bottom" 
                                        title="Clique para salvar">Salvar</button>
                                <a href="<?= base_url('intranet/marcas/'); ?>"
                                   class="btn btn-secondary text-white"
                                   aria-current="page" 
                                   data-toggle="tooltip" 
                                   data-placement="bottom" 
                                   title="Clique para cancelar a edição">Cancel</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>