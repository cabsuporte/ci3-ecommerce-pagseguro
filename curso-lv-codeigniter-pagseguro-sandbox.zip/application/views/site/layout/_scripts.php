<!-- jQuery-V1.12.4 -->
<script src="<?= base_url('frontend/'); ?>js/vendor/jquery-1.12.4.min.js"></script>
<!-- Popper js -->
<script src="<?= base_url('frontend/'); ?>js/vendor/popper.min.js"></script>
<!-- Bootstrap V4.1.3 Fremwork js -->
<script src="<?= base_url('frontend/'); ?>js/bootstrap.min.js"></script>
<!-- Ajax Mail js -->
<script src="<?= base_url('frontend/'); ?>js/ajax-mail.js"></script>
<!-- Meanmenu js -->
<script src="<?= base_url('frontend/'); ?>js/jquery.meanmenu.min.js"></script>
<!-- Wow.min js -->
<script src="<?= base_url('frontend/'); ?>js/wow.min.js"></script>
<!-- Slick Carousel js -->
<script src="<?= base_url('frontend/'); ?>js/slick.min.js"></script>
<!-- Owl Carousel-2 js -->
<script src="<?= base_url('frontend/'); ?>js/owl.carousel.min.js"></script>
<!-- Magnific popup js -->
<script src="<?= base_url('frontend/'); ?>js/jquery.magnific-popup.min.js"></script>
<!-- Isotope js -->
<script src="<?= base_url('frontend/'); ?>js/isotope.pkgd.min.js"></script>
<!-- Imagesloaded js -->
<script src="<?= base_url('frontend/'); ?>js/imagesloaded.pkgd.min.js"></script>
<!-- Mixitup js -->
<script src="<?= base_url('frontend/'); ?>js/jquery.mixitup.min.js"></script>
<!-- Countdown -->
<script src="<?= base_url('frontend/'); ?>js/jquery.countdown.min.js"></script>
<!-- Counterup -->
<script src="<?= base_url('frontend/'); ?>js/jquery.counterup.min.js"></script>
<!-- Waypoints -->
<script src="<?= base_url('frontend/'); ?>js/waypoints.min.js"></script>
<!-- Barrating -->
<script src="<?= base_url('frontend/'); ?>js/jquery.barrating.min.js"></script>
<!-- Jquery-ui -->
<script src="<?= base_url('frontend/'); ?>js/jquery-ui.min.js"></script>
<!-- Venobox -->
<script src="<?= base_url('frontend/'); ?>js/venobox.min.js"></script>
<!-- Nice Select js -->
<script src="<?= base_url('frontend/'); ?>js/jquery.nice-select.min.js"></script>
<!-- ScrollUp js -->
<script src="<?= base_url('frontend/'); ?>js/scrollUp.min.js"></script>
<!-- Main/Activator js -->
<script src="<?= base_url('frontend/'); ?>js/main.js"></script>

<?php if (isset($scripts)): ?>
    <?php foreach ($scripts as $script): ?>
        <script src="<?= base_url('assets/' . $script); ?>"></script>
    <?php endforeach; ?>
<?php endif; ?>