<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-laugh-wink"></i>
        </div>
        <div class="sidebar-brand-text mx-3">CSOS</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url(); ?>" title="Volte para página principal">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Home</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCadastros" 
           aria-expanded="true" aria-controls="collapseCadastros" title="Controle e cadastros do sistema">
            <i class="fas fa-fw fa-users"></i>
            <span>Cadastros</span>
        </a>
        <div id="collapseCadastros" class="collapse" aria-labelledby="headingCadastros" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Clique em uma opção:</h6>
                <a class="collapse-item" href="<?= base_url('clientes'); ?>" title="Cadastro de Clientes">Clientes</a>
                <a class="collapse-item" href="<?= base_url('fornecedores'); ?>" title="Cadastro de Fornecedores">Fornecedores</a>
                <a class="collapse-item" href="<?= base_url('servicos'); ?>" title="Cadastro de Serviços">Serviços</a>
                <a class="collapse-item" href="<?= base_url('vendedores'); ?>" title="Cadastro de Vendedores">Vendedores</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEstoque" 
           aria-expanded="true" aria-controls="collapseEstoque" title="Controle de estoque">
            <i class="fas fa-fw fa-users"></i>
            <span>Estoque</span>
        </a>
        <div id="collapseEstoque" class="collapse" aria-labelledby="headingEstoque" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Clique em uma opção:</h6>
                <a class="collapse-item" href="<?= base_url('categorias'); ?>" title="Controle e cadastro de Categorias">Categorias</a>
                <a class="collapse-item" href="<?= base_url('marcas'); ?>" title="Controle e cadastro de Marcas">Marcas</a>
                <a class="collapse-item" href="<?= base_url('produtos'); ?>" title="Controle e cadastro de Produtos">Produtos</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFinanciero" 
           aria-expanded="true" aria-controls="collapseFinanciero" title="Controle financeiros do sistema">
            <i class="fas fa-fw fa-money-bill"></i>
            <span>Financiero</span>
        </a>
        <div id="collapseFinanciero" class="collapse" aria-labelledby="headingFinanciero" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Clique em uma opção:</h6>
                <a class="collapse-item" href="<?= base_url('pagar/'); ?>" title="Controle e cadastro de Contas a pagar">Contas a pagar</a>
                <a class="collapse-item" href="<?= base_url('receber/'); ?>" title="Controle e cadastro de Contas a receber">Contas a receber</a>
                <a class="collapse-item" href="<?= base_url('modulos/'); ?>" title="Controle e cadastro de Formas de pagamento">Formas de pagamento</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseVendas" 
           aria-expanded="true" aria-controls="collapseVendas" title="Sitema de Vendas">
            <i class="fas fa-fw fa-shopping-cart"></i>
            <span>Vendas</span>
        </a>
        <div id="collapseVendas" class="collapse" aria-labelledby="headingVendas" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Clique em uma opção:</h6>
                <a class="collapse-item" href="<?= base_url('os/'); ?>" title="Gerenciamento de Ordem de serviços">Ordem de serviços</a>
                <a class="collapse-item" href="<?= base_url('vendas/'); ?>" title="Gerenciamento de Vendas">Vendas</a>
            </div>
        </div>
    </li>

    <?php if ($this->ion_auth->is_admin()): ?>
        <!-- Nav Item - Tables -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseRelatorios" 
               aria-expanded="true" aria-controls="collapseRelatorios" title="Relatórios do sistemas OS">
                <i class="fas fa-fw fa-search-dollar"></i>
                <span>Relatórios</span>
            </a>
            <div id="collapseRelatorios" class="collapse" aria-labelledby="headingRelatorios" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Clique em uma opção:</h6>
                    <a class="collapse-item" href="<?= base_url('relatorios/pagar/'); ?>" title="Gerar relatórios de Contas a Pagar">Contas a pagar</a>
                    <a class="collapse-item" href="<?= base_url('relatorios/receber/'); ?>" title="Gerar relatórios de Contas a Receber">Contas a receber</a>
                    <a class="collapse-item" href="<?= base_url('relatorios/os/'); ?>" title="Gerar relatórios de Ordem de serviços">Ordem de serviços</a>
                    <a class="collapse-item" href="<?= base_url('relatorios/vendas/'); ?>" title="Gerar relatórios de vendas">Vendas</a>
                    <a class="collapse-item" href="<?= base_url('relatorios/'); ?>" title="Gerar relatórios de vendas">TODOS</a>
                </div>
            </div>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider">

        <!-- Nav Item - Tables -->
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSistema" 
               aria-expanded="true" aria-controls="collapseSistema" title="Configurações do sistema">
                <i class="fas fa-fw fa-shopping-cart"></i>
                <span>Sistema</span>
            </a>
            <div id="collapseSistema" class="collapse" aria-labelledby="headingSistema" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header">Clique em uma opção:</h6>
                    <a class="collapse-item" href="<?= base_url('sistema/'); ?>" title="Gerenciamento do Sistema">Sistema</a>
                    <a class="collapse-item" href="<?= base_url('usuarios'); ?>" title="Controle e cadastro de Usuários">Usuários</a>
                    <a class="collapse-item" href="<?= base_url('usuarios/editar/' . $this->session->userdata('user_id')); ?>" title="Perfil do Usuário">Perfil</a>
                </div>
            </div>
        </li>

        <!-- Divider -->
        <hr class="sidebar-divider">

    <?php endif; ?>

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">