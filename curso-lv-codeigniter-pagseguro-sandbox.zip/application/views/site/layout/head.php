<!doctype html>
<html class="no-js" lang="pt-BR">

    <!-- index28:48-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?= (isset($titulo)? $titulo: 'Home || Loja Virtual em CodeIgniter 3 com PagSeguro') ;?></title>
        <meta name="description" content="Loja Virtual em CodeIgniter 3 com PagSeguro">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">

        <?php $this->load->view('site/layout/_styles'); ?>

        <script>
            var BASE_URL = "<?= base_url(); ?>";
        </script>
        <style>
            .hb-menu nav > ul> li:first-child> a::after{
                content:"";
            }
            .hb-menu nav > ul> li:last-child> a::after{
                content:"\f107";
            }
            .hb-menu nav > ul> li:nth-child(-n+2){
                margin-right: auto;
            }
            
        </style>
    </head>
    <body>
        <!--[if lt IE 8]>
                    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
            <![endif]-->
        <!-- Begin Body Wrapper -->
        <div class="body-wrapper">

