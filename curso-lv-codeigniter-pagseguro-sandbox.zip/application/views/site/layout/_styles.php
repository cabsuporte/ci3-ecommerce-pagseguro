<!-- Material Design Iconic Font-V2.2.0 -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/material-design-iconic-font.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/font-awesome.min.css">
<!-- Font Awesome Stars-->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/fontawesome-stars.css">
<!-- Meanmenu CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/meanmenu.css">
<!-- owl carousel CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/owl.carousel.min.css">
<!-- Slick Carousel CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/slick.css">
<!-- Animate CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/animate.css">
<!-- Jquery-ui CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/jquery-ui.min.css">
<!-- Venobox CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/venobox.css">
<!-- Nice Select CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/nice-select.css">
<!-- Magnific Popup CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/magnific-popup.css">
<!-- Bootstrap V4.1.3 Fremwork CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/bootstrap.min.css">
<!-- Helper CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/helper.css">
<!-- Main Style CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>style.css">
<!-- Responsive CSS -->
<link rel="stylesheet" href="<?= base_url('frontend/'); ?>css/responsive.css">
<!-- Modernizr js -->
<script src="<?= base_url('frontend/'); ?>js/vendor/modernizr-2.8.3.min.js"></script>

<?php if (isset($styles)): ?>
    <?php foreach ($styles as $style): ?>
        <link href="<?= base_url('asset/' . $style); ?>" rel="stylesheet">
    <?php endforeach; ?>
<?php endif; ?>