<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['intranet'] = 'intranet/Home/index';

$route['produto/(:any)'] = 'Produto/index/$1';
$route['categorias/(:any)'] = 'Categorias/index/$1';
$route['subcategorias/(:any)'] = 'Subcategorias/index/$1';
$route['marcas/(:any)'] = 'Marcas/index/$1';
$route['busca'] = 'Busca/index/';
