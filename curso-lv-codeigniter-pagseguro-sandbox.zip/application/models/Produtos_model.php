<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Produtos_model extends CI_Model {

    public function Get_All() {
        $this->db->SELECT([
            'produtos.*',
            'categorias.categoria_id',
            'categorias.categoria_nome',
            'subcategorias.subcategoria_id',
            'subcategorias.subcategoria_nome',
            'marcas.marca_nome',
        ]);
        $this->db->JOIN('categorias', 'categorias.categoria_id = produtos.produto_categoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('subcategorias', 'subcategorias.subcategoria_id = produtos.produto_subcategoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('marcas', 'marcas.marca_id = produtos.produto_marca_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.

        return $this->db->GET('produtos')->result();
    }

    public function get_by_id($produto_meta_link = NULL) {
        $this->db->SELECT([
            'produtos.*',
            'categorias.*',
            'subcategorias.*',
            'marcas.*',
        ]);
        $this->db->WHERE('produtos.produto_meta_link', $produto_meta_link);
        $this->db->JOIN('categorias', 'categorias.categoria_id = produtos.produto_categoria_id'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('subcategorias', 'subcategorias.subcategoria_id = produtos.produto_subcategoria_id'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('marcas', 'marcas.marca_id = produtos.produto_marca_id'); // O LEFT força dados até que não tem categorias atraladas.

        return $this->db->GET('produtos')->row(); // Rotarno um único dado do array de objetos.
    }

    public function get_all_by($condicoes = NULL) {
        $this->db->SELECT([
            'produtos.*',
            'categorias.*',
            'subcategorias.*',
            'produtos_fotos.*'
        ]);
        $this->db->WHERE('produtos.produto_ativo', 1);

        if ($condicoes && is_array($condicoes)) {
            $this->db->WHERE($condicoes);
        }

        $this->db->JOIN('categorias', 'categorias.categoria_id = produtos.produto_categoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('subcategorias', 'subcategorias.subcategoria_id = produtos.produto_subcategoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('marcas', 'marcas.marca_id = produtos.produto_marca_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('produtos_fotos', 'produtos_fotos.foto_produto_id = produtos.produto_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        // Retorna apenas uma foto por registro
        $this->db->GROUP_BY('produtos.produto_id');

        return $this->db->GET('produtos')->result();
    }

    // Retorna os produtos de acordo com busca
    public function get_all_by_busca($busca = NULL) {
        if ($busca) {
            $this->db->SELECT([
                'produtos.*',
                'categorias.*',
                'subcategorias.*',
                'produtos_fotos.*',
            ]);
            $this->db->WHERE('produtos.produto_ativo', 1);
            
            $this->db->LIKE('produtos.produto_nome', $busca, 'BOTH');
            
            $this->db->JOIN('categorias', 'categorias.categoria_id = produtos.produto_categoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
            $this->db->JOIN('subcategorias', 'subcategorias.subcategoria_id = produtos.produto_subcategoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
            $this->db->JOIN('marcas', 'marcas.marca_id = produtos.produto_marca_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
            $this->db->JOIN('produtos_fotos', 'produtos_fotos.foto_produto_id = produtos.produto_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
            
            $this->db->GROUP_BY('produtos.produto_id');
            
            return $this->db->GET('produtos')->result();
        } else {
            return false;
        }
    }

}