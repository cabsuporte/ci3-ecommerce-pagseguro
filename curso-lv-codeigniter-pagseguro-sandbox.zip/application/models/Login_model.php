<?php
defined('BASEPATH')OR exit ('No direct script access allowed');

class Login_model extends CI_Model{
    
    public function entrar(){
        $inputEmail = $this->input->POST('inputEmail');
        $inputSenha = $this->input->POST('inputSenha');
        
        $this->db->WHERE('email_usuario', $inputEmail);
        $this->db->WHERE('senha_usuario', $inputSenha);
        $consultar = $this->db->GET('lme_usuarios');
        
        if($consultar->num_rows()>0){
            return $consultar;
        }else{
            return false;
        }
    }
}