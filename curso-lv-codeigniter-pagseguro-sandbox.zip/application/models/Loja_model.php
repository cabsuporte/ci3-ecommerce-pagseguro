<?php

defined('BASEPATH') OR exit('Nenhuma ação permitida!');

class Loja_model extends CI_Model {

    public function get_grandes_marcas() {
        $this->db->SELECT([
            'marcas.*'
        ]);
        $this->db->WHERE('marca_ativa', 1);
        $this->db->JOIN('produtos', 'produtos.produto_marca_id = marcas.marca_id');
        $this->db->GROUP_BY('marca_nome');

        return $this->db->GET('marcas')->result();
    }

    public function get_categorias(){ // Categorias da navbar
        $this->db->SELECT([
            'categorias.*',
            'produtos.produto_nome',
        ]);
        
        $this->db->WHERE('categoria_ativa', 1);
        $this->db->JOIN('subcategorias', 'subcategorias.categoria_id = categorias.categoria_id', 'LEFT');// Puxa as subcategorias pertinentes as categorias.
        $this->db->JOIN('produtos', 'produtos.produto_subcategoria_id = subcategorias.subcategoria_id'); // Sem o LEFT, trás a consulta somente associada ao produto. Puxa as produtos pertinentes as categorias.
        $this->db->GROUP_BY('categorias.categoria_nome'); // Não deixa repetir, função parecida com DISTINCT.
        return $this->db->GET('categorias')->result();
    }
    
    public function get_subcategorias($categoria_id = NULL){
        $this->db->SELECT([
            'subcategorias.*',
            'produtos.produto_nome',
        ]);
        $this->db->WHERE('subcategorias.categoria_id', $categoria_id);
        $this->db->WHERE('subcategorias.subcategoria_ativa', 1);
        $this->db->JOIN('produtos', 'produtos.produto_subcategoria_id = subcategorias.subcategoria_id'); // Sem o LEFT, trás a consulta somente associada ao produto.
        $this->db->GROUP_BY('subcategorias.subcategoria_nome'); // Não deixa repetir, função parecida com DISTINCT.
        
        return $this->db->GET('subcategorias')->result();
    }
    
    // Produtos destaques
    public function get_produtos_destaques($num_produtos_destaques = NULL){
        $this->db->SELECT([
            'produtos.produto_id',
            'produtos.produto_nome',
            'produtos.produto_valor',
            'produtos.produto_meta_link',
            'produtos.produto_quantidade_estoque',
            'produtos_fotos.foto_caminho',
            'categorias.categoria_nome'
        ]);
        $this->db->JOIN('produtos_fotos', 'produtos_fotos.foto_produto_id = produtos.produto_id');
        $this->db->JOIN('categorias', 'categorias.categoria_id = produtos.produto_categoria_id');
        $this->db->WHERE('produtos.produto_destaque', 1);
        $this->db->WHERE('produtos.produto_ativo', 1);
        
        $this->db->LIMIT($num_produtos_destaques);
        $this->db->GROUP_BY('produtos.produto_id');
        
        return $this->db->GET('produtos')->result();
    }
}
