<?php

defined('BASEPATH') OR exit('Ação não permitida');

class Subcategorias_model extends CI_Model {

    public function Get_All() {
        $this->db->SELECT([
            'subcategorias.*',
            'categorias.*',
        ]);
        $this->db->JOIN('categorias', 'categorias.categoria_id = subcategorias.categoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        return $this->db->GET('subcategorias')->result();
    }

    public function get_by_id($produto_id = NULL) {
        $this->db->SELECT([
            'produtos.*',
//            'subcategorias.subcategoria_id',
            'subcategorias.subcategoria_nome',
            'marcas.marca_nome',
        ]);
        $this->db->JOIN('subcategorias', 'subcategorias.subcategoria_id = produtos.produto_subcategoria_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.
        $this->db->JOIN('marcas', 'marcas.marca_id = produtos.produto_marca_id', 'LEFT'); // O LEFT força dados até que não tem categorias atraladas.

        return $this->db->GET('produtos')->row(); // Rotarno um único dado do array de objetos.
    }

}
